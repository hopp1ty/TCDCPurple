PRIVESC DETECTION MONITORS — README
===================================

Two blue-team detection scripts for a purple-team exercise. They watch host
telemetry and FLAG behavior consistent with privilege escalation. They do not
perform privesc — pair them with a red-side atomic (Atomic Red Team) and
confirm the matching alert fires.

FILES
-----
privesc_monitor.py        Linux  — Python 3, reads auditd/auth logs + live scan
Invoke-PrivescMonitor.ps1 Windows — PowerShell, reads Security + Sysmon logs

LINUX USAGE
-----------
  sudo python3 privesc_monitor.py --follow   # continuous (default)
  sudo python3 privesc_monitor.py --once     # single baseline scan
Alerts: JSON-lines to stdout and ./privesc_alerts.log
Best coverage with auditd installed and running. For richer signal, add audit
rules, e.g.:
  auditctl -a always,exit -F arch=b64 -S execve -F euid=0 -k privesc
  auditctl -w /etc/passwd -p wa -k sensitive
  auditctl -w /etc/sudoers -p wa -k sensitive

WINDOWS USAGE
-------------
  .\Invoke-PrivescMonitor.ps1 -Follow        # continuous
  .\Invoke-PrivescMonitor.ps1 -Once          # single scan
Run elevated. Install Sysmon with a tuned config (SwiftOnSecurity or
Olaf Hartong sysmon-modular) for the process/registry/file detections.
Alerts: JSON to stdout and .\privesc_alerts.log

COVERAGE — ATT&CK MAPPING
-------------------------
Linux:
  T1548.001  SUID/SGID abuse, unusual setuid binaries
  T1548.003  sudo abuse, writable sudoers fragments
  T1068      pkexec (CVE-2021-4034 class)
  T1136.001  new local account
  T1098      user added to privileged group
  T1222.002  sensitive file (passwd/shadow/sudoers) modification
  T1547      kernel module load
  T1543.002  systemd unit changes

Windows:
  T1078       admin-equivalent token at logon (4672)
  T1134       sensitive privilege use / token manipulation (4673/4674)
  T1134.001   named-pipe impersonation hints
  T1134.002   runas / explicit-cred logon (4648)
  T1098       privileged group membership change (4728/4732/4756) + live snapshot
  T1136.001   account creation (4720)
  T1543.003   service install (4697)
  T1053.005   scheduled task creation (4698)
  T1548.002   UAC bypass (auto-elevate binaries), AlwaysInstallElevated
  T1574.009   unquoted service path
  T1003       credential-dumping tooling (often paired with privesc)

RUNNING IT AS A PURPLE EXERCISE
-------------------------------
1. Start the monitor on each target host (one terminal, leave it tailing).
2. Red runs a single atomic for a technique above.
3. Blue confirms the alert line with the matching attack_technique appears.
4. Log the timestamp; note any technique that produced NO alert — that gap is
   the most valuable output of the day (a detection you need to build).

TUNING
------
- These favor sensitivity over precision so blue sees the signal first, then
  tightens. Expect benign hits (admin activity) — triage and suppress by host.
- Forward privesc_alerts.log into your SIEM (Elastic/Wazuh) to correlate with
  Sigma rules rather than reading JSON by hand.
