#!/usr/bin/env python3
"""
beacon_detector.py — C2 beaconing / jitter-interval analyzer
============================================================
Blue-team detection. Flags command-and-control beaconing
(ATT&CK T1071 / T1571) by finding src->dst:port channels whose connection
timing is suspiciously regular. Human/app traffic is bursty and irregular;
a beacon phones home on a fixed cadence (often with small jitter), producing
low variance in inter-arrival times.

For each channel it computes:
  - number of connections (need enough samples)
  - mean inter-arrival time (the candidate beacon interval)
  - coefficient of variation (CV = stddev/mean) of intervals  -> regularity
  - MAD-based jitter ratio                                     -> robustness
  - data-size consistency (optional, from conn.log bytes)
Low CV + enough connections over enough time => beacon alert.

Input: a Zeek conn.log (batch analysis; re-run on a rolling window).
    python3 beacon_detector.py --zeek /opt/zeek/logs/current/conn.log
    python3 beacon_detector.py --zeek conn.log --watch 300   # re-run every 5m

Tunables:
    --min-conns N    minimum connections per channel (default 8)
    --cv FLOAT       max coefficient of variation to flag (default 0.15)
    --min-span SECS  minimum timespan the channel must cover (default 600)
"""

import argparse
import json
import os
import statistics
import time
from collections import defaultdict
from datetime import datetime, timezone

ALERT_LOG = "beacon_alerts.log"

# Destinations that are noisy-but-benign regular talkers.
WHITELIST_PORTS = {123}  # NTP is legitimately periodic
WHITELIST_HOSTS = set()  # add known update/telemetry servers here


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def emit(technique, severity, message, evidence=None):
    alert = {
        "time": now_iso(),
        "detector": "beacon",
        "attack_technique": technique,
        "severity": severity,
        "message": message,
        "evidence": evidence or {},
    }
    line = json.dumps(alert)
    print(line, flush=True)
    try:
        with open(ALERT_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def zeek_header(path):
    """Return {field_name: index} from a Zeek TSV log, or None."""
    try:
        with open(path, "r", errors="ignore") as f:
            for line in f:
                if line.startswith("#fields"):
                    fields = line.strip().split("\t")[1:]
                    return {n: i for i, n in enumerate(fields)}
    except OSError:
        return None
    return None


def load_channels(path, idx):
    """Group connection start-times (and bytes) by src->dst:port channel."""
    channels = defaultdict(list)   # key -> list[(ts, orig_bytes)]
    i_ts = idx.get("ts")
    i_src = idx.get("id.orig_h")
    i_dst = idx.get("id.resp_h")
    i_port = idx.get("id.resp_p")
    i_bytes = idx.get("orig_bytes")
    if None in (i_ts, i_src, i_dst, i_port):
        return channels
    with open(path, "r", errors="ignore") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            c = line.rstrip("\n").split("\t")
            try:
                ts = float(c[i_ts])
                src = c[i_src]
                dst = c[i_dst]
                port = c[i_port]
            except (IndexError, ValueError):
                continue
            if port.isdigit() and int(port) in WHITELIST_PORTS:
                continue
            if dst in WHITELIST_HOSTS:
                continue
            b = 0
            if i_bytes is not None and i_bytes < len(c):
                try:
                    b = int(c[i_bytes]) if c[i_bytes] not in ("-", "") else 0
                except ValueError:
                    b = 0
            channels[(src, dst, port)].append((ts, b))
    return channels


def analyze(channels, args):
    for (src, dst, port), events in channels.items():
        if len(events) < args.min_conns:
            continue
        events.sort(key=lambda e: e[0])
        times = [e[0] for e in events]
        span = times[-1] - times[0]
        if span < args.min_span:
            continue

        intervals = [t2 - t1 for t1, t2 in zip(times, times[1:])]
        intervals = [i for i in intervals if i > 0]
        if len(intervals) < args.min_conns - 1:
            continue

        mean = statistics.mean(intervals)
        if mean <= 0:
            continue
        stdev = statistics.pstdev(intervals)
        cv = stdev / mean   # coefficient of variation; lower = more regular

        # MAD-based jitter ratio (robust to a few outliers)
        med = statistics.median(intervals)
        mad = statistics.median([abs(i - med) for i in intervals]) or 0.0
        jitter_ratio = (mad / med) if med else 1.0

        # Data-size consistency: beacons often send similar-sized check-ins.
        sizes = [b for _, b in events if b > 0]
        size_cv = (statistics.pstdev(sizes) / statistics.mean(sizes)
                   if len(sizes) >= args.min_conns and statistics.mean(sizes) > 0
                   else None)

        regular = cv <= args.cv or jitter_ratio <= args.cv
        if regular:
            sev = "high" if cv <= args.cv / 2 else "medium"
            emit("T1071", sev,
                 f"Possible C2 beacon {src} -> {dst}:{port} "
                 f"every ~{mean:.1f}s (CV={cv:.3f})",
                 {"src": src, "dst": dst, "port": port,
                  "connections": len(events),
                  "interval_seconds": round(mean, 1),
                  "cv": round(cv, 3),
                  "jitter_ratio": round(jitter_ratio, 3),
                  "timespan_seconds": round(span, 1),
                  "size_cv": round(size_cv, 3) if size_cv is not None else None})


def run_once(path, args):
    idx = zeek_header(path)
    if not idx:
        emit("-", "error",
             f"Could not read Zeek header from {path}. Is it a conn.log?")
        return
    channels = load_channels(path, idx)
    emit("-", "info", f"Analyzing {len(channels)} channels from {path}")
    analyze(channels, args)
    emit("-", "info", "Beacon analysis pass complete")


def main():
    ap = argparse.ArgumentParser(description="C2 beaconing detector (Zeek conn.log)")
    ap.add_argument("--zeek", default="conn.log", help="Path to Zeek conn.log")
    ap.add_argument("--min-conns", type=int, default=8)
    ap.add_argument("--cv", type=float, default=0.15)
    ap.add_argument("--min-span", type=int, default=600)
    ap.add_argument("--watch", type=int, default=0,
                    help="Re-run every N seconds (0 = single pass)")
    args = ap.parse_args()

    if not os.path.exists(args.zeek):
        emit("-", "error", f"conn.log not found: {args.zeek}")
        return

    emit("-", "info", "Beacon detector starting")
    try:
        if args.watch > 0:
            while True:
                run_once(args.zeek, args)
                time.sleep(args.watch)
        else:
            run_once(args.zeek, args)
    except KeyboardInterrupt:
        emit("-", "info", "Stopped by operator")


if __name__ == "__main__":
    main()
