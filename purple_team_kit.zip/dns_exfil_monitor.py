#!/usr/bin/env python3
"""
dns_exfil_monitor.py — DNS exfiltration / tunneling detector
============================================================
Blue-team detection. Flags DNS-based exfiltration and tunneling
(ATT&CK T1048.003 / T1071.004) by looking for the statistical fingerprints
of data smuggled through DNS:
  - high Shannon entropy in the queried label (encoded data)
  - unusually long query names / long leftmost labels
  - high query VOLUME to a single parent domain in a short window
  - high count of UNIQUE subdomains under one parent (data chunking)
  - rare / high-entropy TXT or NULL query patterns

Input (pick one):
  --zeek PATH     tail a Zeek dns.log (default: ./dns.log if present)
  --live IFACE    sniff live with scapy (needs root + scapy installed)

Usage:
    python3 dns_exfil_monitor.py --zeek /opt/zeek/logs/current/dns.log
    sudo python3 dns_exfil_monitor.py --live eth0

Tunables:
    --entropy FLOAT     per-label entropy threshold (default 3.5 bits/char)
    --minlen INT        query length to consider long (default 50)
    --window SECS       volume window (default 60)
    --vol INT           queries/parent/window to alert (default 80)
    --uniq INT          unique subdomains/parent/window to alert (default 40)
"""

import argparse
import json
import math
import os
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

ALERT_LOG = "dns_exfil_alerts.log"

# Common domains that legitimately generate lots of varied subdomains.
WHITELIST_PARENTS = {
    "in-addr.arpa", "ip6.arpa", "akamai.net", "akamaiedge.net",
    "cloudfront.net", "amazonaws.com", "googleusercontent.com",
    "windowsupdate.com", "office365.com", "sophosxl.net", "trendmicro.com",
}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def emit(technique, severity, message, evidence=None):
    alert = {
        "time": now_iso(),
        "detector": "dns_exfil",
        "attack_technique": technique,
        "severity": severity,
        "message": message,
        "evidence": evidence or {},
    }
    line = json.dumps(alert)
    print(line, flush=True)
    try:
        with open(ALERT_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def shannon_entropy(s):
    if not s:
        return 0.0
    freq = defaultdict(int)
    for ch in s:
        freq[ch] += 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def parent_domain(qname):
    """Return registrable-ish parent (last two labels)."""
    q = qname.rstrip(".")
    parts = q.split(".")
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    return q


def leftmost_label(qname):
    q = qname.rstrip(".")
    return q.split(".")[0] if q else ""


class Analyzer:
    def __init__(self, args):
        self.a = args
        self.vol = defaultdict(deque)          # parent -> deque[ts]
        self.uniq = defaultdict(lambda: deque())  # parent -> deque[(ts, sub)]
        self.uniq_set = defaultdict(set)       # parent -> set(sub) in window
        self.alerted = {}

    def _trim(self, parent, nowt):
        w = self.a.window
        dq = self.vol[parent]
        while dq and nowt - dq[0] > w:
            dq.popleft()
        uq = self.uniq[parent]
        while uq and nowt - uq[0][0] > w:
            _, old_sub = uq.popleft()
            # rebuild set lazily below
        # rebuild unique set from the trimmed deque
        self.uniq_set[parent] = {s for _, s in self.uniq[parent]}

    def observe(self, qname, qtype="A", nowt=None):
        nowt = nowt or time.time()
        if not qname:
            return
        parent = parent_domain(qname)
        if parent in WHITELIST_PARENTS or any(
                parent.endswith(w) for w in WHITELIST_PARENTS):
            return

        label = leftmost_label(qname)
        ent = shannon_entropy(label)
        qlen = len(qname.rstrip("."))

        # 1. Per-query encoding fingerprint
        if ent >= self.a.entropy and len(label) >= 12:
            self._alert(parent, "high",
                        f"High-entropy DNS label ({ent:.2f} bits/char) under {parent}",
                        {"qname": qname[:200], "qtype": qtype,
                         "entropy": round(ent, 2), "label_len": len(label)})
        if qlen >= self.a.minlen:
            self._alert(parent, "medium",
                        f"Unusually long DNS query ({qlen} chars) under {parent}",
                        {"qname": qname[:200], "qtype": qtype, "length": qlen})
        if qtype in ("TXT", "NULL", "CNAME") and ent >= self.a.entropy:
            self._alert(parent, "high",
                        f"High-entropy {qtype} query under {parent} (tunneling)",
                        {"qname": qname[:200], "qtype": qtype,
                         "entropy": round(ent, 2)})

        # 2. Volume / chunking fingerprint
        self.vol[parent].append(nowt)
        self.uniq[parent].append((nowt, label))
        self.uniq_set[parent].add(label)
        self._trim(parent, nowt)

        vcount = len(self.vol[parent])
        ucount = len(self.uniq_set[parent])
        if vcount >= self.a.vol:
            self._alert(parent, "high",
                        f"High DNS volume to {parent}: {vcount} queries/"
                        f"{self.a.window}s",
                        {"parent": parent, "queries": vcount})
        if ucount >= self.a.uniq:
            self._alert(parent, "high",
                        f"Many unique subdomains under {parent}: {ucount}/"
                        f"{self.a.window}s (data chunking)",
                        {"parent": parent, "unique_subdomains": ucount})

    def _alert(self, parent, sev, msg, ev):
        key = (parent, msg.split(":")[0])
        last = self.alerted.get(key, 0)
        nowt = time.time()
        if nowt - last < self.a.window:   # throttle per parent+reason
            return
        self.alerted[key] = nowt
        emit("T1048.003", sev, msg, ev)


# ---------------- Zeek input ----------------

def zeek_field_index(header_line):
    # Zeek TSV header: "#fields ts uid ... query qtype_name ..."
    fields = header_line.strip().split("\t")[1:]
    return {name: i for i, name in enumerate(fields)}


def run_zeek(path, analyzer):
    emit("-", "info", f"Tailing Zeek dns.log: {path}")
    idx = None
    with open(path, "r", errors="ignore") as f:
        # Read existing header if present, then tail.
        f.seek(0)
        for line in f:
            if line.startswith("#fields"):
                idx = zeek_field_index(line)
                break
        f.seek(0, os.SEEK_END)
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.4)
                continue
            if line.startswith("#fields"):
                idx = zeek_field_index(line)
                continue
            if line.startswith("#") or not idx:
                continue
            cols = line.rstrip("\n").split("\t")
            try:
                q = cols[idx.get("query", 9)]
                qt = cols[idx.get("qtype_name", 13)] if "qtype_name" in idx else "A"
            except IndexError:
                continue
            if q and q != "-":
                analyzer.observe(q, qt)


# ---------------- Live capture (scapy) ----------------

def run_live(iface, analyzer):
    try:
        from scapy.all import sniff, DNS, DNSQR  # noqa
    except ImportError:
        emit("-", "error",
             "scapy not installed. pip install scapy, or use --zeek.")
        return
    emit("-", "info", f"Sniffing DNS on {iface} (scapy)")

    def handle(pkt):
        if pkt.haslayer(DNSQR):
            try:
                qname = pkt[DNSQR].qname.decode(errors="ignore")
                qtype = pkt[DNSQR].qtype
                tmap = {1: "A", 28: "AAAA", 16: "TXT", 5: "CNAME", 10: "NULL"}
                analyzer.observe(qname, tmap.get(qtype, str(qtype)))
            except Exception:  # noqa
                pass

    from scapy.all import sniff  # noqa
    sniff(iface=iface, filter="udp port 53", prn=handle, store=False)


def main():
    ap = argparse.ArgumentParser(description="DNS exfiltration / tunneling detector")
    ap.add_argument("--zeek", nargs="?", const="dns.log")
    ap.add_argument("--live")
    ap.add_argument("--entropy", type=float, default=3.5)
    ap.add_argument("--minlen", type=int, default=50)
    ap.add_argument("--window", type=int, default=60)
    ap.add_argument("--vol", type=int, default=80)
    ap.add_argument("--uniq", type=int, default=40)
    args = ap.parse_args()

    analyzer = Analyzer(args)
    emit("-", "info", "DNS exfil monitor starting")

    try:
        if args.live:
            run_live(args.live, analyzer)
        else:
            path = args.zeek or "dns.log"
            if not os.path.exists(path):
                emit("-", "error",
                     f"Zeek log not found: {path}. Use --zeek PATH or --live IFACE.")
                return
            run_zeek(path, analyzer)
    except KeyboardInterrupt:
        emit("-", "info", "Stopped by operator")


if __name__ == "__main__":
    main()
