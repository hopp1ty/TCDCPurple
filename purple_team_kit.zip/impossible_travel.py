#!/usr/bin/env python3
"""
impossible_travel.py — impossible-travel / anomalous-logon detector
===================================================================
Blue-team detection. Flags logons that imply a user physically moved between
two locations faster than is possible (ATT&CK T1078 Valid Accounts / credential
compromise), plus logons from new countries and sudden multi-geo activity.

For each successful logon it records (user, source_ip, time, geo). When the
same user logs in again, it computes the great-circle distance to the previous
login and the implied travel speed. Speed above a threshold (default 900 km/h,
~commercial jet) is flagged as impossible travel.

GEO RESOLUTION (offline-first):
  - Preferred: MaxMind GeoLite2-City DB via the geoip2 library.
      pip install geoip2 ; download GeoLite2-City.mmdb (free account)
      python3 impossible_travel.py --geodb GeoLite2-City.mmdb --log auth.log
  - Degraded mode (no DB): can't geolocate, so it instead flags a user
    authenticating from multiple DISTINCT public IPs within a short window.

INPUT:
  --log PATH    Linux auth log (sshd "Accepted ... from <ip>")
  --json PATH   newline-delimited JSON events: {"user","ip","time"(iso)}
                (use this to feed Windows 4624 exported from Get-WinEvent)

Usage:
    python3 impossible_travel.py --geodb GeoLite2-City.mmdb --log /var/log/auth.log
    python3 impossible_travel.py --json logons.jsonl --once
"""

import argparse
import ipaddress
import json
import math
import os
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

ALERT_LOG = "impossible_travel_alerts.log"

MAX_SPEED_KMH = 900.0      # above this between two logons = impossible
MULTI_IP_WINDOW = 600      # seconds, for degraded-mode multi-IP flag

RE_SSH_OK = re.compile(
    r"Accepted (?:password|publickey|keyboard-interactive).*for (\S+) "
    r"from (\d{1,3}(?:\.\d{1,3}){3})", re.I)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def emit(technique, severity, message, evidence=None):
    alert = {
        "time": now_iso(),
        "detector": "impossible_travel",
        "attack_technique": technique,
        "severity": severity,
        "message": message,
        "evidence": evidence or {},
    }
    line = json.dumps(alert)
    print(line, flush=True)
    try:
        with open(ALERT_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def is_public(ip):
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = (math.sin(dp / 2) ** 2 +
         math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2)
    return 2 * r * math.asin(math.sqrt(a))


class Geo:
    def __init__(self, dbpath):
        self.reader = None
        if dbpath:
            try:
                import geoip2.database  # noqa
                self.reader = geoip2.database.Reader(dbpath)
            except ImportError:
                emit("-", "warn", "geoip2 not installed; running degraded (no geo).")
            except Exception as e:  # noqa
                emit("-", "warn", f"Could not open geo DB ({e}); degraded mode.")

    def lookup(self, ip):
        if not self.reader:
            return None
        try:
            r = self.reader.city(ip)
            return {"lat": r.location.latitude, "lon": r.location.longitude,
                    "country": r.country.iso_code, "city": r.city.name}
        except Exception:  # noqa
            return None


class Tracker:
    def __init__(self, geo):
        self.geo = geo
        self.last = {}                        # user -> (ts, ip, geo)
        self.seen_countries = defaultdict(set)
        self.recent_ips = defaultdict(deque)  # user -> deque[(ts, ip)]

    def _parse_time(self, t):
        if isinstance(t, (int, float)):
            return float(t)
        if isinstance(t, str):
            try:
                return datetime.fromisoformat(t.replace("Z", "+00:00")).timestamp()
            except ValueError:
                return time.time()
        return time.time()

    def observe(self, user, ip, t=None):
        if not user or not ip:
            return
        ts = self._parse_time(t) if t is not None else time.time()

        # Degraded-mode multi-IP burst
        if is_public(ip):
            dq = self.recent_ips[user]
            dq.append((ts, ip))
            while dq and ts - dq[0][0] > MULTI_IP_WINDOW:
                dq.popleft()
            distinct = {p for _, p in dq}
            if len(distinct) >= 3:
                emit("T1078", "medium",
                     f"User '{user}' authenticated from {len(distinct)} distinct "
                     f"public IPs within {MULTI_IP_WINDOW}s",
                     {"user": user, "ips": sorted(distinct)})

        g = self.geo.lookup(ip) if is_public(ip) else None

        # New-country flag
        if g and g.get("country"):
            if (self.seen_countries[user] and
                    g["country"] not in self.seen_countries[user]):
                emit("T1078", "medium",
                     f"User '{user}' logon from new country: {g['country']}",
                     {"user": user, "ip": ip, "country": g["country"],
                      "city": g.get("city")})
            self.seen_countries[user].add(g["country"])

        # Impossible-travel check vs previous logon
        prev = self.last.get(user)
        if prev and g:
            pts, pip, pg = prev
            if pg and pts and ts > pts:
                dist = haversine_km(pg["lat"], pg["lon"], g["lat"], g["lon"])
                hours = (ts - pts) / 3600.0
                if hours > 0 and dist > 50:   # ignore tiny/same-city moves
                    speed = dist / hours
                    if speed > MAX_SPEED_KMH:
                        emit("T1078", "high",
                             f"Impossible travel for '{user}': "
                             f"{dist:.0f} km in {hours*60:.0f} min "
                             f"(~{speed:.0f} km/h)",
                             {"user": user,
                              "from": {"ip": pip, "country": pg.get("country"),
                                       "city": pg.get("city")},
                              "to": {"ip": ip, "country": g.get("country"),
                                     "city": g.get("city")},
                              "distance_km": round(dist),
                              "elapsed_min": round(hours * 60),
                              "implied_kmh": round(speed)})
        if g:
            self.last[user] = (ts, ip, g)


def follow_file(path):
    with open(path, "r", errors="ignore") as f:
        f.seek(0, os.SEEK_END)
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.4)
                continue
            yield line


def run_authlog(path, tracker, once):
    emit("-", "info", f"Reading SSH logons from {path}")
    if once:
        with open(path, "r", errors="ignore") as f:
            for line in f:
                m = RE_SSH_OK.search(line)
                if m:
                    tracker.observe(m.group(1), m.group(2))
        return
    for line in follow_file(path):
        m = RE_SSH_OK.search(line)
        if m:
            tracker.observe(m.group(1), m.group(2))


def run_jsonl(path, tracker, once):
    emit("-", "info", f"Reading JSON logon events from {path}")

    def handle(line):
        line = line.strip()
        if not line:
            return
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            return
        tracker.observe(ev.get("user"), ev.get("ip"), ev.get("time"))

    if once:
        with open(path, "r", errors="ignore") as f:
            for line in f:
                handle(line)
        return
    for line in follow_file(path):
        handle(line)


def main():
    ap = argparse.ArgumentParser(description="Impossible-travel logon detector")
    ap.add_argument("--geodb", help="Path to GeoLite2-City.mmdb")
    ap.add_argument("--log", help="Linux auth log path")
    ap.add_argument("--json", help="Newline-delimited JSON logon events")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--max-speed", type=float, default=MAX_SPEED_KMH)
    args = ap.parse_args()

    global MAX_SPEED_KMH
    MAX_SPEED_KMH = args.max_speed

    if not args.log and not args.json:
        emit("-", "error", "Provide --log <auth.log> or --json <events.jsonl>")
        return

    geo = Geo(args.geodb)
    tracker = Tracker(geo)
    emit("-", "info", "Impossible-travel monitor starting")
    try:
        if args.json:
            run_jsonl(args.json, tracker, args.once)
        else:
            run_authlog(args.log, tracker, args.once)
    except KeyboardInterrupt:
        emit("-", "info", "Stopped by operator")


if __name__ == "__main__":
    main()
