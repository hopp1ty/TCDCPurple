#!/usr/bin/env python3
"""
privesc_monitor.py  —  Linux privilege-escalation detection monitor
===================================================================
Blue-team detection script for a purple-team exercise.

It does NOT perform privilege escalation. It watches host telemetry and
raises flagged alerts when behavior consistent with common privesc
techniques appears, so the blue team can confirm detections fire when the
red team runs the matching atomic.

Data sources (best effort — it uses whatever is present):
  - auditd log           (/var/log/audit/audit.log)   [preferred]
  - authentication log   (/var/log/auth.log or /var/log/secure)
  - live scan of SUID/SGID binaries and world-writable sensitive files

Run as root (read access to audit/auth logs) for full coverage:
    sudo python3 privesc_monitor.py --follow

One-shot baseline + scan (no tailing):
    sudo python3 privesc_monitor.py --once

Output: JSON-lines alerts to stdout and to ./privesc_alerts.log
        Each alert carries an ATT&CK technique id for the run sheet.
"""

import argparse
import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone

ALERT_LOG = "privesc_alerts.log"

AUDIT_LOG = "/var/log/audit/audit.log"
AUTH_LOGS = ["/var/log/auth.log", "/var/log/secure"]

# Known-dangerous SUID binaries (GTFOBins style) that should rarely be SUID.
SUSPICIOUS_SUID = {
    "nmap", "vim", "vi", "find", "bash", "sh", "dash", "more", "less",
    "nano", "cp", "mv", "awk", "perl", "python", "python3", "ruby", "lua",
    "php", "env", "tar", "zip", "docker", "tee",
}

# Sensitive files whose modification is a strong privesc signal.
SENSITIVE_FILES = ["/etc/passwd", "/etc/shadow", "/etc/sudoers"]
SENSITIVE_DIRS = ["/etc/sudoers.d"]

# auth.log / secure patterns
AUTH_PATTERNS = [
    # technique_id, label, compiled regex
    ("T1548.003", "sudo authentication failure",
     re.compile(r"sudo:.*authentication failure", re.I)),
    ("T1548.003", "sudo command by non-privileged context",
     re.compile(r"sudo:.*COMMAND=", re.I)),
    ("T1136.001", "new user account created",
     re.compile(r"(useradd|adduser)\[", re.I)),
    ("T1098",     "user added to privileged group",
     re.compile(r"(usermod|gpasswd).*(sudo|wheel|admin|root)", re.I)),
    ("T1548.001", "setuid/setgid change via chmod",
     re.compile(r"chmod.*(4[0-7]{3}|u\+s|g\+s)", re.I)),
    ("T1068",     "pkexec invocation (CVE-2021-4034 class)",
     re.compile(r"pkexec", re.I)),
    ("T1543.002", "systemd service/unit change",
     re.compile(r"systemctl.*(enable|start).*", re.I)),
]

# auditd raw patterns (when auditd is present and verbose)
AUDIT_PATTERNS = [
    ("T1548.001", "execution of setuid binary",
     re.compile(r"type=SYSCALL.*(suid|setuid)", re.I)),
    ("T1547",     "kernel module load",
     re.compile(r"type=SYSCALL.*(init_module|finit_module)", re.I)),
    ("T1222.002", "permission change on sensitive path",
     re.compile(r"type=PATH.*/etc/(passwd|shadow|sudoers)", re.I)),
]


def now():
    return datetime.now(timezone.utc).isoformat()


def emit(technique, severity, message, evidence=None):
    alert = {
        "time": now(),
        "attack_technique": technique,
        "severity": severity,
        "message": message,
        "evidence": evidence or {},
        "host": os.uname().nodename,
    }
    line = json.dumps(alert)
    print(line, flush=True)
    try:
        with open(ALERT_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ---------- point-in-time scans ----------

def scan_suid_binaries():
    """Flag unusual SUID/SGID binaries across common PATH dirs."""
    search_dirs = ["/usr/bin", "/usr/sbin", "/bin", "/sbin",
                   "/usr/local/bin", "/usr/local/sbin", "/tmp", "/home"]
    for d in search_dirs:
        if not os.path.isdir(d):
            continue
        for root, _, files in os.walk(d):
            for name in files:
                path = os.path.join(root, name)
                try:
                    st = os.stat(path)
                except OSError:
                    continue
                suid = bool(st.st_mode & 0o4000)
                sgid = bool(st.st_mode & 0o2000)
                if not (suid or sgid):
                    continue
                base = name.lower()
                # SUID binary living in a writable/user location is suspicious
                in_user_space = root.startswith(("/tmp", "/home"))
                if base in SUSPICIOUS_SUID or in_user_space:
                    emit(
                        "T1548.001",
                        "high" if in_user_space else "medium",
                        f"Unusual {'SUID' if suid else 'SGID'} binary: {path}",
                        {"path": path, "owner_uid": st.st_uid,
                         "mode": oct(st.st_mode)},
                    )


def hash_file(path):
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def baseline_sensitive_files():
    base = {}
    for p in SENSITIVE_FILES:
        base[p] = hash_file(p)
    return base


def check_sensitive_changes(baseline):
    for p in SENSITIVE_FILES:
        current = hash_file(p)
        if baseline.get(p) and current and current != baseline[p]:
            emit(
                "T1222.002",
                "high",
                f"Sensitive file modified: {p}",
                {"path": p, "sha256_before": baseline[p],
                 "sha256_after": current},
            )
            baseline[p] = current


def check_writable_sudoers():
    for d in SENSITIVE_DIRS:
        if not os.path.isdir(d):
            continue
        for name in os.listdir(d):
            path = os.path.join(d, name)
            try:
                st = os.stat(path)
            except OSError:
                continue
            if st.st_mode & 0o022:  # group/other writable
                emit("T1548.003", "high",
                     f"World/group-writable sudoers fragment: {path}",
                     {"path": path, "mode": oct(st.st_mode)})


# ---------- log following ----------

def follow(path):
    """Generator that yields new lines appended to a file (tail -f)."""
    with open(path, "r", errors="ignore") as f:
        f.seek(0, os.SEEK_END)
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.5)
                continue
            yield line


def scan_line(line, patterns):
    for technique, label, rx in patterns:
        if rx.search(line):
            emit(technique, "medium", label, {"log_line": line.strip()[:400]})


def pick_auth_log():
    for p in AUTH_LOGS:
        if os.path.exists(p):
            return p
    return None


def run_once():
    emit("-", "info", "Starting one-shot privesc baseline scan")
    scan_suid_binaries()
    check_writable_sudoers()
    base = baseline_sensitive_files()
    check_sensitive_changes(base)
    emit("-", "info", "One-shot scan complete")


def run_follow():
    emit("-", "info", "Starting continuous privesc monitor")
    scan_suid_binaries()
    check_writable_sudoers()
    baseline = baseline_sensitive_files()

    auth_log = pick_auth_log()
    sources = []
    if os.path.exists(AUDIT_LOG) and os.access(AUDIT_LOG, os.R_OK):
        sources.append((AUDIT_LOG, AUDIT_PATTERNS))
        emit("-", "info", f"Tailing auditd: {AUDIT_LOG}")
    if auth_log and os.access(auth_log, os.R_OK):
        sources.append((auth_log, AUTH_PATTERNS))
        emit("-", "info", f"Tailing auth log: {auth_log}")

    if not sources:
        emit("-", "warn",
             "No readable audit/auth logs. Run as root, or use --once.")
        return

    # Simple round-robin tail across sources + periodic re-scan.
    followers = [(follow(path), pats) for path, pats in sources]
    last_rescan = time.time()
    while True:
        for gen, pats in followers:
            try:
                line = next(gen)
                if line:
                    scan_line(line, pats)
            except StopIteration:
                pass
        if time.time() - last_rescan > 60:
            check_sensitive_changes(baseline)
            check_writable_sudoers()
            last_rescan = time.time()


def main():
    ap = argparse.ArgumentParser(description="Linux privesc detection monitor")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--follow", action="store_true",
                   help="Continuously tail logs and re-scan (default)")
    g.add_argument("--once", action="store_true",
                   help="Run a single baseline scan and exit")
    args = ap.parse_args()

    if args.once:
        run_once()
    else:
        try:
            run_follow()
        except KeyboardInterrupt:
            emit("-", "info", "Monitor stopped by operator")


if __name__ == "__main__":
    main()
