<#
.SYNOPSIS
    Invoke-WindowsHardening.ps1 — audit/apply a Windows security baseline.

.DESCRIPTION
    Blue-team hardening script for a purple-team exercise. On a host you
    administer, it checks a set of CIS-aligned security settings and reports
    each as PASS / FAIL, and — only when -Apply is given — remediates them.

    It touches: account & lockout policy, local security options, audit policy
    (so detection tooling has telemetry), Windows Firewall, SMB/LM/NTLM
    settings, UAC, RDP, service hardening, and key filesystem/registry ACLs.

    SAFE BY DEFAULT:
      - No switches  -> AUDIT ONLY. Nothing is changed.
      - -Apply       -> applies remediations.
      - -Backup      -> export current policy/registry state before applying.

    Run from an ELEVATED PowerShell prompt.

.EXAMPLE
    .\Invoke-WindowsHardening.ps1                 # audit, report only
    .\Invoke-WindowsHardening.ps1 -Apply -Backup  # back up, then harden
    .\Invoke-WindowsHardening.ps1 -Apply -Only Firewall,AuditPolicy

.NOTES
    Test in your lab/range first. Some controls (SMBv1 removal, RDP NLA,
    firewall default-deny) can affect connectivity — review before -Apply on
    anything you rely on remote access to.
#>

[CmdletBinding()]
param(
    [switch]$Apply,
    [switch]$Backup,
    [ValidateSet('AccountPolicy','AuditPolicy','SecurityOptions','Firewall',
                 'SMB','UAC','RDP','Services','ACLs')]
    [string[]]$Only,
    [string]$LogPath = ".\hardening_report.log",
    [string]$BackupDir = ".\hardening_backup"
)

if (-not ([Security.Principal.WindowsPrincipal] `
          [Security.Principal.WindowsIdentity]::GetCurrent()
         ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run this from an elevated (Administrator) PowerShell prompt."
    exit 1
}

$script:Results = @()
$script:Mode = if ($Apply) { "APPLY" } else { "AUDIT" }

function Log {
    param([string]$Text)
    $line = "{0}  {1}" -f (Get-Date).ToString("s"), $Text
    Write-Host $line
    Add-Content -Path $LogPath -Value $line -ErrorAction SilentlyContinue
}

function Record {
    param(
        [string]$Category,
        [string]$Control,
        [ValidateSet('PASS','FAIL','FIXED','SKIP','ERROR')][string]$Status,
        [string]$Detail = ""
    )
    $script:Results += [pscustomobject]@{
        Category = $Category; Control = $Control
        Status = $Status; Detail = $Detail
    }
    Log ("[{0}] {1} :: {2} {3}" -f $Status, $Category, $Control,
         ($(if ($Detail){"- $Detail"})))
}

function Want {
    param([string]$Section)
    if (-not $Only) { return $true }
    return $Only -contains $Section
}

# Set a registry value (reports PASS if already compliant, FIXED if changed).
function Ensure-RegValue {
    param(
        [string]$Category, [string]$Control,
        [string]$Path, [string]$Name,
        [Parameter(Mandatory)]$Value,
        [ValidateSet('DWord','String','ExpandString','QWord')]
        [string]$Type = 'DWord'
    )
    try {
        $current = $null
        if (Test-Path $Path) {
            $current = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name
        }
        if ($current -eq $Value) {
            Record $Category $Control 'PASS' "$Name=$current"
            return
        }
        if (-not $Apply) {
            Record $Category $Control 'FAIL' "$Name is '$current', want '$Value'"
            return
        }
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
        Record $Category $Control 'FIXED' "$Name -> $Value"
    } catch {
        Record $Category $Control 'ERROR' $_.Exception.Message
    }
}

# ---------------------------------------------------------------------------
function Backup-State {
    if (-not $Backup) { return }
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    Log "Backing up current state to $BackupDir"
    try { secedit /export /cfg "$BackupDir\secpol_before.cfg" | Out-Null } catch {}
    try { auditpol /get /category:* > "$BackupDir\auditpol_before.txt" } catch {}
    try { reg export HKLM\SYSTEM\CurrentControlSet\Control\Lsa "$BackupDir\lsa_before.reg" /y | Out-Null } catch {}
    try { Get-NetFirewallProfile | Select-Object * | Out-File "$BackupDir\firewall_before.txt" } catch {}
    Record "Backup" "Pre-change snapshot" "PASS" $BackupDir
}

# ---- 1. Account & lockout policy (via secedit) ----------------------------
function Harden-AccountPolicy {
    if (-not (Want 'AccountPolicy')) { return }
    $desired = @{
        MinimumPasswordLength      = 14
        PasswordComplexity         = 1
        MaximumPasswordAge         = 365
        MinimumPasswordAge         = 1
        PasswordHistorySize        = 24
        LockoutBadCount            = 5
        ResetLockoutCount          = 15
        LockoutDuration            = 15
    }
    $tmp = "$env:TEMP\secpol_cur.cfg"
    try { secedit /export /cfg $tmp /quiet } catch {
        Record "AccountPolicy" "export" "ERROR" $_.Exception.Message; return
    }
    $content = Get-Content $tmp
    $changed = $false
    foreach ($k in $desired.Keys) {
        $want = $desired[$k]
        $line = $content | Where-Object { $_ -match "^\s*$k\s*=" }
        $cur = if ($line) { ($line -split '=')[1].Trim() } else { "<unset>" }
        if ("$cur" -eq "$want") {
            Record "AccountPolicy" $k "PASS" "$cur"
        } elseif (-not $Apply) {
            Record "AccountPolicy" $k "FAIL" "is $cur, want $want"
        } else {
            if ($line) {
                $content = $content -replace "^\s*$k\s*=.*", "$k = $want"
            } else {
                $content += "$k = $want"
            }
            $changed = $true
            Record "AccountPolicy" $k "FIXED" "-> $want"
        }
    }
    if ($Apply -and $changed) {
        $content | Set-Content $tmp
        $db = "$env:TEMP\secpol.sdb"
        secedit /configure /db $db /cfg $tmp /areas SECURITYPOLICY /quiet
    }
}

# ---- 2. Audit policy (feed the detection tooling) -------------------------
function Harden-AuditPolicy {
    if (-not (Want 'AuditPolicy')) { return }
    # subcategory -> success,failure
    $subs = @(
        @('Logon','enable','enable'),
        @('Logoff','enable','disable'),
        @('Special Logon','enable','disable'),
        @('User Account Management','enable','enable'),
        @('Security Group Management','enable','enable'),
        @('Process Creation','enable','disable'),
        @('Sensitive Privilege Use','enable','enable'),
        @('Audit Policy Change','enable','enable'),
        @('Authorization Policy Change','enable','enable')
    )
    foreach ($s in $subs) {
        $name,$succ,$fail = $s
        try {
            $cur = auditpol /get /subcategory:"$name" 2>$null
            $ok = ($cur -match "Success and Failure") -or
                  ($succ -eq 'enable' -and $fail -eq 'disable' -and $cur -match "Success")
            if ($ok -and -not $Apply) { Record "AuditPolicy" $name "PASS"; continue }
            if (-not $Apply) { Record "AuditPolicy" $name "FAIL" "needs $succ/$fail"; continue }
            auditpol /set /subcategory:"$name" /success:$succ /failure:$fail | Out-Null
            Record "AuditPolicy" $name "FIXED" "success:$succ failure:$fail"
        } catch { Record "AuditPolicy" $name "ERROR" $_.Exception.Message }
    }
    # Enable PowerShell script-block + command-line process logging
    Ensure-RegValue "AuditPolicy" "PowerShell ScriptBlock logging" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" `
        "EnableScriptBlockLogging" 1
    Ensure-RegValue "AuditPolicy" "Command line in process events" `
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" `
        "ProcessCreationIncludeCmdLine_Enabled" 1
}

# ---- 3. Security options / LSA / credential protections -------------------
function Harden-SecurityOptions {
    if (-not (Want 'SecurityOptions')) { return }
    $lsa = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
    Ensure-RegValue "SecurityOptions" "Restrict anonymous SAM enumeration" $lsa "RestrictAnonymousSAM" 1
    Ensure-RegValue "SecurityOptions" "Restrict anonymous shares"          $lsa "RestrictAnonymous" 1
    Ensure-RegValue "SecurityOptions" "Disable LM hash storage"            $lsa "NoLMHash" 1
    Ensure-RegValue "SecurityOptions" "LM compatibility (NTLMv2 only)"     $lsa "LmCompatibilityLevel" 5
    Ensure-RegValue "SecurityOptions" "Enable LSASS protection (RunAsPPL)" $lsa "RunAsPPL" 1
    Ensure-RegValue "SecurityOptions" "Restrict Credential Delegation"     `
        "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Credential Delegation" "AllowProtectedCreds" 1
    # WDigest cleartext creds off (Mimikatz mitigation)
    Ensure-RegValue "SecurityOptions" "Disable WDigest cleartext creds"    `
        "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" "UseLogonCredential" 0
}

# ---- 4. Windows Firewall --------------------------------------------------
function Harden-Firewall {
    if (-not (Want 'Firewall')) { return }
    foreach ($p in 'Domain','Private','Public') {
        try {
            $prof = Get-NetFirewallProfile -Profile $p
            $good = $prof.Enabled -and $prof.DefaultInboundAction -eq 'Block'
            if ($good -and -not $Apply) { Record "Firewall" "$p profile" "PASS"; continue }
            if (-not $Apply) {
                Record "Firewall" "$p profile" "FAIL" "enabled=$($prof.Enabled) inbound=$($prof.DefaultInboundAction)"
                continue
            }
            Set-NetFirewallProfile -Profile $p -Enabled True `
                -DefaultInboundAction Block -DefaultOutboundAction Allow `
                -LogBlocked True -LogFileName "%systemroot%\system32\LogFiles\Firewall\pfirewall.log"
            Record "Firewall" "$p profile" "FIXED" "enabled, default-deny inbound, logging on"
        } catch { Record "Firewall" "$p profile" "ERROR" $_.Exception.Message }
    }
}

# ---- 5. SMB hardening -----------------------------------------------------
function Harden-SMB {
    if (-not (Want 'SMB')) { return }
    # Disable SMBv1
    try {
        $v1 = Get-SmbServerConfiguration
        if (-not $v1.EnableSMB1Protocol -and -not $Apply) {
            Record "SMB" "SMBv1 disabled" "PASS"
        } elseif (-not $Apply) {
            Record "SMB" "SMBv1 disabled" "FAIL" "SMBv1 is enabled"
        } else {
            Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force
            Record "SMB" "SMBv1 disabled" "FIXED"
        }
    } catch { Record "SMB" "SMBv1 disabled" "ERROR" $_.Exception.Message }
    # Require SMB signing
    try {
        $cfg = Get-SmbServerConfiguration
        if ($cfg.RequireSecuritySignature -and -not $Apply) {
            Record "SMB" "Require SMB signing" "PASS"
        } elseif (-not $Apply) {
            Record "SMB" "Require SMB signing" "FAIL"
        } else {
            Set-SmbServerConfiguration -RequireSecuritySignature $true -Force
            Record "SMB" "Require SMB signing" "FIXED"
        }
    } catch { Record "SMB" "Require SMB signing" "ERROR" $_.Exception.Message }
}

# ---- 6. UAC ---------------------------------------------------------------
function Harden-UAC {
    if (-not (Want 'UAC')) { return }
    $sys = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
    Ensure-RegValue "UAC" "UAC enabled (EnableLUA)"            $sys "EnableLUA" 1
    Ensure-RegValue "UAC" "Admin Approval prompt on secure desktop" $sys "PromptOnSecureDesktop" 1
    Ensure-RegValue "UAC" "Consent prompt for admins"         $sys "ConsentPromptBehaviorAdmin" 2
    Ensure-RegValue "UAC" "Deny elevation to standard users"  $sys "ConsentPromptBehaviorUser" 0
    Ensure-RegValue "UAC" "Disable AlwaysInstallElevated (HKLM)" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer" "AlwaysInstallElevated" 0
}

# ---- 7. RDP ---------------------------------------------------------------
function Harden-RDP {
    if (-not (Want 'RDP')) { return }
    $ts = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
    Ensure-RegValue "RDP" "Require Network Level Authentication" $ts "UserAuthentication" 1
    Ensure-RegValue "RDP" "Require high encryption"              $ts "MinEncryptionLevel" 3
    # Note: we do NOT auto-disable RDP; it may be your access path.
}

# ---- 8. Service hardening -------------------------------------------------
function Harden-Services {
    if (-not (Want 'Services')) { return }
    # Services commonly abused / rarely needed on servers & workstations.
    $disable = @{
        'RemoteRegistry' = 'Remote Registry'
        'SSDPSRV'        = 'SSDP Discovery'
        'upnphost'       = 'UPnP Device Host'
        'WMPNetworkSvc'  = 'WMP Network Sharing'
    }
    foreach ($name in $disable.Keys) {
        try {
            $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
            if (-not $svc) { Record "Services" $disable[$name] "SKIP" "not present"; continue }
            $start = (Get-CimInstance Win32_Service -Filter "Name='$name'").StartMode
            if ($start -eq 'Disabled' -and -not $Apply) {
                Record "Services" $disable[$name] "PASS"; continue
            }
            if (-not $Apply) { Record "Services" $disable[$name] "FAIL" "StartMode=$start"; continue }
            Stop-Service -Name $name -Force -ErrorAction SilentlyContinue
            Set-Service -Name $name -StartupType Disabled
            Record "Services" $disable[$name] "FIXED" "stopped + disabled"
        } catch { Record "Services" $disable[$name] "ERROR" $_.Exception.Message }
    }
}

# ---- 9. Filesystem / registry ACL checks ----------------------------------
function Harden-ACLs {
    if (-not (Want 'ACLs')) { return }
    # Flag writable-by-non-admins on sensitive dirs (report; don't auto-chmod).
    $paths = @("$env:SystemRoot\System32", "$env:SystemRoot",
               "$env:ProgramFiles", "${env:ProgramFiles(x86)}")
    foreach ($p in $paths) {
        if (-not (Test-Path $p)) { continue }
        try {
            $acl = Get-Acl $p
            $weak = $acl.Access | Where-Object {
                $_.FileSystemRights -match 'Write|Modify|FullControl' -and
                $_.AccessControlType -eq 'Allow' -and
                $_.IdentityReference -match 'Everyone|Users|Authenticated Users|BUILTIN\\Users'
            }
            if ($weak) {
                Record "ACLs" "Writable sensitive path: $p" "FAIL" `
                    (($weak.IdentityReference | Select-Object -Unique) -join ', ')
            } else {
                Record "ACLs" "Sensitive path ACL: $p" "PASS"
            }
        } catch { Record "ACLs" $p "ERROR" $_.Exception.Message }
    }
    # Report non-default local administrators for review.
    try {
        $admins = Get-LocalGroupMember -Group "Administrators" |
                  Select-Object -ExpandProperty Name
        Record "ACLs" "Local Administrators membership" "PASS" ($admins -join ', ')
    } catch { Record "ACLs" "Local Administrators membership" "ERROR" $_.Exception.Message }
}

# ---------------------------------------------------------------------------
Log "=== Windows hardening ($script:Mode mode) on $env:COMPUTERNAME ==="
if ($Apply) { Log "APPLY mode: remediations WILL be written." }
else { Log "AUDIT mode: reporting only, no changes." }

Backup-State
Harden-AccountPolicy
Harden-AuditPolicy
Harden-SecurityOptions
Harden-Firewall
Harden-SMB
Harden-UAC
Harden-RDP
Harden-Services
Harden-ACLs

# ---- summary --------------------------------------------------------------
$summary = $script:Results | Group-Object Status |
           Select-Object Name, Count | Sort-Object Name
Log "---- SUMMARY ----"
foreach ($row in $summary) { Log ("{0}: {1}" -f $row.Name, $row.Count) }

$fails = $script:Results | Where-Object Status -eq 'FAIL'
if ($fails -and -not $Apply) {
    Log "Re-run with -Apply (and -Backup) to remediate the FAIL items above."
}
Log "Full report written to $LogPath"

# Emit the result table as objects too (pipe to Export-Csv if desired).
$script:Results
