<#
.SYNOPSIS
    Invoke-WindowsHardening-Extended.ps1 — advanced hardening controls.

.DESCRIPTION
    Companion to Invoke-WindowsHardening.ps1. Adds the higher-tier controls:
      - Defender Attack Surface Reduction (ASR) rules  (audit or block)
      - Legacy name-resolution poisoning surface: LLMNR / NetBIOS / mDNS / WPAD
      - Credential Guard (VBS) enablement flags
      - NTLMv1 disable + NTLM auditing
      - PowerShell transcription + module logging
      - Print Spooler control on servers (PrintNightmare surface)
      - Microsoft Defender posture (cloud protection, PUA, tamper check)

    SAFE BY DEFAULT:
      - No switches -> AUDIT ONLY (reports PASS/FAIL, changes nothing).
      - -Apply      -> applies remediations.
      - ASR rules go to AUDIT mode unless you pass -AsrBlock (so you get the
        detection telemetry first without breaking anything).

    Run from an ELEVATED PowerShell prompt. Test in the lab/range first —
    several of these (Credential Guard, spooler, NTLMv1) can affect
    compatibility. Review before -Apply on production.

.EXAMPLE
    .\Invoke-WindowsHardening-Extended.ps1                     # audit all
    .\Invoke-WindowsHardening-Extended.ps1 -Apply              # apply, ASR=audit
    .\Invoke-WindowsHardening-Extended.ps1 -Apply -AsrBlock    # apply, ASR=block
    .\Invoke-WindowsHardening-Extended.ps1 -Only ASR,PowerShell
#>

[CmdletBinding()]
param(
    [switch]$Apply,
    [switch]$AsrBlock,
    [switch]$Backup,
    [ValidateSet('ASR','NameResolution','CredentialGuard','NTLM',
                 'PowerShell','Spooler','Defender')]
    [string[]]$Only,
    [string]$LogPath   = ".\hardening_extended_report.log",
    [string]$BackupDir = ".\hardening_backup"
)

if (-not ([Security.Principal.WindowsPrincipal] `
          [Security.Principal.WindowsIdentity]::GetCurrent()
         ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run this from an elevated (Administrator) PowerShell prompt."
    exit 1
}

$script:Results = @()

function Log {
    param([string]$Text)
    $line = "{0}  {1}" -f (Get-Date).ToString("s"), $Text
    Write-Host $line
    Add-Content -Path $LogPath -Value $line -ErrorAction SilentlyContinue
}
function Record {
    param([string]$Category,[string]$Control,
          [ValidateSet('PASS','FAIL','FIXED','SKIP','ERROR')][string]$Status,
          [string]$Detail="")
    $script:Results += [pscustomobject]@{Category=$Category;Control=$Control;Status=$Status;Detail=$Detail}
    Log ("[{0}] {1} :: {2} {3}" -f $Status,$Category,$Control,($(if($Detail){"- $Detail"})))
}
function Want { param([string]$S) if (-not $Only){return $true}; return $Only -contains $S }

function Ensure-RegValue {
    param([string]$Category,[string]$Control,[string]$Path,[string]$Name,
          [Parameter(Mandatory)]$Value,
          [ValidateSet('DWord','String','ExpandString','QWord')][string]$Type='DWord')
    try {
        $current=$null
        if (Test-Path $Path){ $current=(Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name }
        if ($current -eq $Value){ Record $Category $Control 'PASS' "$Name=$current"; return }
        if (-not $Apply){ Record $Category $Control 'FAIL' "$Name is '$current', want '$Value'"; return }
        if (-not (Test-Path $Path)){ New-Item -Path $Path -Force | Out-Null }
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
        Record $Category $Control 'FIXED' "$Name -> $Value"
    } catch { Record $Category $Control 'ERROR' $_.Exception.Message }
}

function Backup-State {
    if (-not $Backup){ return }
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    try { reg export "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" "$BackupDir\defender_before.reg" /y | Out-Null } catch {}
    try { Get-MpPreference | Out-File "$BackupDir\mppreference_before.txt" } catch {}
    Record "Backup" "Pre-change snapshot" "PASS" $BackupDir
}

# ---- 1. ASR rules ---------------------------------------------------------
function Harden-ASR {
    if (-not (Want 'ASR')) { return }
    # GUID -> friendly name. Audit=2, Block=1, Off=0.
    $rules = [ordered]@{
        "56a863a9-875e-4185-98a7-b882c64b5ce5"="Block abuse of exploited vulnerable signed drivers"
        "7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c"="Block Adobe Reader from creating child processes"
        "d4f940ab-401b-4efc-aadc-ad5f3c50688a"="Block Office apps creating child processes"
        "9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2"="Block credential stealing from LSASS"
        "be9ba2d9-53ea-4cdc-84e5-9b1eeee46550"="Block executable content from email/webmail"
        "01443614-cd74-433a-b99e-2ecdc07bfc25"="Block untrusted/unsigned executables from USB"
        "5beb7efe-fd9a-4556-801d-275e5ffc04cc"="Block execution of potentially obfuscated scripts"
        "d3e037e1-3eb8-44c8-a917-57927947596d"="Block JS/VBScript launching downloaded content"
        "3b576869-a4ec-4529-8536-b80a7769e899"="Block Office apps creating executable content"
        "75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84"="Block Office apps injecting into other processes"
        "26190899-1602-49e8-8b27-eb1d0a1ce869"="Block Office comms app child processes"
        "e6db77e5-3df2-4cf1-b95a-636979351e5b"="Block persistence through WMI event subscription"
        "d1e49aac-8f56-4280-b9ba-993a6d77406c"="Block process creations from PSExec/WMI commands"
        "b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4"="Block untrusted/unsigned processes from USB"
        "c1db55ab-c21a-4637-bb3f-a12568109d35"="Use advanced ransomware protection"
    }
    $mode = if ($AsrBlock) { 1 } else { 2 }  # default audit
    $modeName = if ($AsrBlock) { "Block" } else { "Audit" }

    try { $existing = (Get-MpPreference).AttackSurfaceReductionRules_Ids } catch { $existing=@() }
    try { $states   = (Get-MpPreference).AttackSurfaceReductionRules_Actions } catch { $states=@() }
    $map = @{}
    for ($i=0; $i -lt $existing.Count; $i++){ $map[$existing[$i]] = $states[$i] }

    foreach ($guid in $rules.Keys) {
        $name = $rules[$guid]
        $cur = $map[$guid]
        if ($cur -eq $mode){ Record "ASR" $name "PASS" "$modeName"; continue }
        if (-not $Apply){ Record "ASR" $name "FAIL" "state=$cur want=$modeName"; continue }
        try {
            Add-MpPreference -AttackSurfaceReductionRules_Ids $guid -AttackSurfaceReductionRules_Actions $mode -ErrorAction Stop
            Record "ASR" $name "FIXED" "-> $modeName"
        } catch { Record "ASR" $name "ERROR" $_.Exception.Message }
    }
}

# ---- 2. Name-resolution poisoning surface ---------------------------------
function Harden-NameResolution {
    if (-not (Want 'NameResolution')) { return }
    # LLMNR off
    Ensure-RegValue "NameResolution" "Disable LLMNR" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" "EnableMulticast" 0
    # WPAD off (auto-proxy disclosure / poisoning)
    Ensure-RegValue "NameResolution" "Disable WPAD auto-detect" `
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad" "WpadOverride" 1
    Ensure-RegValue "NameResolution" "Disable NetBIOS over TCP/IP (DHCP default)" `
        "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" "NodeType" 2 'DWord'
    # NetBIOS per-interface (set NetbiosOptions=2 = disabled)
    if ($Apply) {
        try {
            $ifaces = "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces"
            Get-ChildItem $ifaces -ErrorAction SilentlyContinue | ForEach-Object {
                Set-ItemProperty -Path $_.PSPath -Name NetbiosOptions -Value 2 -ErrorAction SilentlyContinue
            }
            Record "NameResolution" "Disable NetBIOS on all interfaces" "FIXED"
        } catch { Record "NameResolution" "Disable NetBIOS on all interfaces" "ERROR" $_.Exception.Message }
    } else {
        Record "NameResolution" "Disable NetBIOS on all interfaces" "FAIL" "set NetbiosOptions=2 per interface"
    }
    # mDNS off
    Ensure-RegValue "NameResolution" "Disable mDNS" `
        "HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" "EnableMDNS" 0
}

# ---- 3. Credential Guard (VBS) --------------------------------------------
function Harden-CredentialGuard {
    if (-not (Want 'CredentialGuard')) { return }
    Ensure-RegValue "CredentialGuard" "Enable VBS" `
        "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" "EnableVirtualizationBasedSecurity" 1
    Ensure-RegValue "CredentialGuard" "Require Secure Boot for VBS" `
        "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard" "RequirePlatformSecurityFeatures" 1
    Ensure-RegValue "CredentialGuard" "Enable Credential Guard (LSA)" `
        "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" "LsaCfgFlags" 1
    Record "CredentialGuard" "Note" "SKIP" "Requires reboot + VBS-capable hardware (UEFI, SLAT, TPM)."
}

# ---- 4. NTLM hardening ----------------------------------------------------
function Harden-NTLM {
    if (-not (Want 'NTLM')) { return }
    $lsa = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
    # LmCompatibilityLevel 5 = send NTLMv2 only, refuse LM & NTLM
    Ensure-RegValue "NTLM" "NTLMv2 only (refuse LM/NTLMv1)" $lsa "LmCompatibilityLevel" 5
    # Audit inbound/outbound NTLM so you can see usage before restricting
    Ensure-RegValue "NTLM" "Audit incoming NTLM traffic" `
        "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" "AuditReceivingNTLMTraffic" 2
    Ensure-RegValue "NTLM" "Audit NTLM auth in this domain" `
        "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" "RestrictSendingNTLMTraffic" 1
}

# ---- 5. PowerShell logging ------------------------------------------------
function Harden-PowerShell {
    if (-not (Want 'PowerShell')) { return }
    Ensure-RegValue "PowerShell" "Script-block logging" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" "EnableScriptBlockLogging" 1
    Ensure-RegValue "PowerShell" "Module logging" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging" "EnableModuleLogging" 1
    Ensure-RegValue "PowerShell" "Module logging: all modules" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging\ModuleNames" "*" "*" 'String'
    Ensure-RegValue "PowerShell" "Transcription enabled" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" "EnableTranscripting" 1
    Ensure-RegValue "PowerShell" "Transcription: include invocation headers" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" "EnableInvocationHeader" 1
    Ensure-RegValue "PowerShell" "Transcription output dir" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\Transcription" "OutputDirectory" "C:\PSTranscripts" 'String'
}

# ---- 6. Print Spooler (PrintNightmare surface) ----------------------------
function Harden-Spooler {
    if (-not (Want 'Spooler')) { return }
    # Block point-and-print privilege escalation; don't blindly kill spooler on
    # workstations that print. Report state; disable only on request via -Apply.
    Ensure-RegValue "Spooler" "Restrict driver install to admins" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" "RestrictDriverInstallationToAdministrators" 1
    Ensure-RegValue "Spooler" "No warning/elevation bypass on new connection" `
        "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" "NoWarningNoElevationOnInstall" 0
    $isServer = (Get-CimInstance Win32_OperatingSystem).ProductType -ne 1
    if ($isServer) {
        $svc = Get-Service -Name Spooler -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq 'Running') {
            if (-not $Apply) {
                Record "Spooler" "Spooler on server" "FAIL" "running; disable if not a print server"
            } else {
                Record "Spooler" "Spooler on server" "SKIP" "Not auto-disabled — confirm host isn't a print server, then: Stop-Service Spooler; Set-Service Spooler -StartupType Disabled"
            }
        } else { Record "Spooler" "Spooler on server" "PASS" "not running" }
    }
}

# ---- 7. Defender posture --------------------------------------------------
function Harden-Defender {
    if (-not (Want 'Defender')) { return }
    try {
        $p = Get-MpPreference
        $s = Get-MpComputerStatus
    } catch {
        Record "Defender" "Get-MpPreference" "ERROR" $_.Exception.Message; return
    }
    # Tamper protection (read-only report; can't be scripted off/on safely)
    Record "Defender" "Tamper Protection" ($(if($s.IsTamperProtected){'PASS'}else{'FAIL'})) `
        "IsTamperProtected=$($s.IsTamperProtected)"
    # Real-time protection
    if ($p.DisableRealtimeMonitoring) {
        if ($Apply){ Set-MpPreference -DisableRealtimeMonitoring $false; Record "Defender" "Real-time protection" "FIXED" }
        else { Record "Defender" "Real-time protection" "FAIL" "disabled" }
    } else { Record "Defender" "Real-time protection" "PASS" }
    # Cloud-delivered protection (MAPS)
    if ($p.MAPSReporting -eq 0) {
        if ($Apply){ Set-MpPreference -MAPSReporting Advanced; Set-MpPreference -SubmitSamplesConsent SendSafeSamples; Record "Defender" "Cloud protection" "FIXED" }
        else { Record "Defender" "Cloud protection" "FAIL" "MAPS off" }
    } else { Record "Defender" "Cloud protection" "PASS" }
    # PUA protection
    if ($p.PUAProtection -ne 1) {
        if ($Apply){ Set-MpPreference -PUAProtection Enabled; Record "Defender" "PUA protection" "FIXED" }
        else { Record "Defender" "PUA protection" "FAIL" }
    } else { Record "Defender" "PUA protection" "PASS" }
    # Controlled Folder Access (ransomware) — audit by default
    if ($p.EnableControlledFolderAccess -eq 0) {
        if ($Apply){ Set-MpPreference -EnableControlledFolderAccess AuditMode; Record "Defender" "Controlled Folder Access" "FIXED" "audit mode" }
        else { Record "Defender" "Controlled Folder Access" "FAIL" "off" }
    } else { Record "Defender" "Controlled Folder Access" "PASS" }
}

# ---- main -----------------------------------------------------------------
$mode = if ($Apply){"APPLY"}else{"AUDIT"}
Log "=== Extended Windows hardening ($mode) on $env:COMPUTERNAME ==="
if ($Apply -and -not $AsrBlock){ Log "ASR rules will be set to AUDIT mode (pass -AsrBlock to enforce)." }
Backup-State
Harden-ASR
Harden-NameResolution
Harden-CredentialGuard
Harden-NTLM
Harden-PowerShell
Harden-Spooler
Harden-Defender

$summary = $script:Results | Group-Object Status | Select-Object Name,Count | Sort-Object Name
Log "---- SUMMARY ----"
foreach ($r in $summary){ Log ("{0}: {1}" -f $r.Name,$r.Count) }
if (($script:Results | Where-Object Status -eq 'FAIL') -and -not $Apply){
    Log "Re-run with -Apply (and -Backup) to remediate. Some controls need a reboot."
}
Log "Full report: $LogPath"
$script:Results
