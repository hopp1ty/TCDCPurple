#!/usr/bin/env python3
"""
brute_force_monitor.py — failed-logon / brute-force correlator
==============================================================
Blue-team detection. Flags password-guessing (ATT&CK T1110) by correlating
failed authentications per source within a sliding time window, and raises a
higher-severity alert on a failure burst immediately followed by a success
(possible successful brute force / credential stuffing).

Cross-platform:
  - Linux  : tails /var/log/auth.log or /var/log/secure (sshd, sudo, etc.)
  - Windows: polls Security log for event 4625 (fail) / 4624 (success)
             via PowerShell Get-WinEvent.

Usage:
    python3 brute_force_monitor.py                 # auto-detect OS, follow
    python3 brute_force_monitor.py --threshold 5 --window 60
    python3 brute_force_monitor.py --once          # single look-back pass

Tunables:
    --threshold N   failures from one source in the window to alert (default 5)
    --window SECS   sliding window length in seconds (default 60)
"""

import argparse
import json
import os
import platform
import re
import subprocess
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

ALERT_LOG = "bruteforce_alerts.log"

LINUX_LOGS = ["/var/log/auth.log", "/var/log/secure"]

# Linux failure / success signatures (sshd + PAM).
RE_FAIL = re.compile(
    r"(Failed password|authentication failure|Invalid user|"
    r"Failed publickey|maximum authentication attempts)", re.I)
RE_SUCCESS = re.compile(r"Accepted (password|publickey|keyboard-interactive)", re.I)
RE_IP = re.compile(r"(?:from\s+)?(\d{1,3}(?:\.\d{1,3}){3})")
RE_USER = re.compile(r"(?:for(?:\s+invalid\s+user)?|user)\s+([A-Za-z0-9._\-\\]+)", re.I)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def emit(technique, severity, message, evidence=None):
    alert = {
        "time": now_iso(),
        "detector": "brute_force",
        "attack_technique": technique,
        "severity": severity,
        "message": message,
        "evidence": evidence or {},
        "host": platform.node(),
    }
    line = json.dumps(alert)
    print(line, flush=True)
    try:
        with open(ALERT_LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


class Correlator:
    """Tracks failures per source IP in a sliding window."""

    def __init__(self, threshold, window):
        self.threshold = threshold
        self.window = window
        self.fails = defaultdict(deque)      # ip -> deque[timestamps]
        self.alerted = {}                    # ip -> last alert time
        self.recent_users = defaultdict(set) # ip -> usernames tried

    def _trim(self, ip, nowt):
        dq = self.fails[ip]
        while dq and nowt - dq[0] > self.window:
            dq.popleft()

    def record_fail(self, ip, user, nowt=None):
        nowt = nowt or time.time()
        if not ip:
            return
        self.fails[ip].append(nowt)
        if user:
            self.recent_users[ip].add(user)
        self._trim(ip, nowt)
        count = len(self.fails[ip])
        if count >= self.threshold:
            last = self.alerted.get(ip, 0)
            if nowt - last > self.window:   # avoid alert spam
                self.alerted[ip] = nowt
                emit("T1110", "high",
                     f"Brute-force: {count} failed logons from {ip} "
                     f"in {self.window}s",
                     {"source_ip": ip, "failures": count,
                      "users_tried": sorted(self.recent_users[ip])[:20]})

    def record_success(self, ip, user, nowt=None):
        nowt = nowt or time.time()
        if not ip:
            return
        self._trim(ip, nowt)
        # Success right after a burst of failures = likely cracked.
        if len(self.fails[ip]) >= max(3, self.threshold - 1):
            emit("T1110", "critical",
                 f"Possible SUCCESSFUL brute force: {ip} authenticated as "
                 f"'{user}' after {len(self.fails[ip])} recent failures",
                 {"source_ip": ip, "user": user,
                  "preceding_failures": len(self.fails[ip])})
        self.fails[ip].clear()


# ---------------- Linux ----------------

def pick_linux_log():
    for p in LINUX_LOGS:
        if os.path.exists(p) and os.access(p, os.R_OK):
            return p
    return None


def follow_file(path):
    with open(path, "r", errors="ignore") as f:
        f.seek(0, os.SEEK_END)
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.4)
                continue
            yield line


def parse_linux_line(line, corr):
    ipm = RE_IP.search(line)
    userm = RE_USER.search(line)
    ip = ipm.group(1) if ipm else None
    user = userm.group(1) if userm else None
    if RE_SUCCESS.search(line):
        corr.record_success(ip, user)
    elif RE_FAIL.search(line):
        corr.record_fail(ip, user)


def run_linux(corr, once, window):
    path = pick_linux_log()
    if not path:
        emit("-", "warn", "No readable auth log found (run with sudo).")
        return
    emit("-", "info", f"Monitoring {path} for brute-force activity")
    if once:
        try:
            with open(path, "r", errors="ignore") as f:
                for line in f.readlines()[-5000:]:
                    parse_linux_line(line, corr)
        except OSError as e:
            emit("-", "error", str(e))
        return
    for line in follow_file(path):
        parse_linux_line(line, corr)


# ---------------- Windows ----------------

PS_QUERY = r"""
$since = (Get-Date).AddSeconds(-{lookback})
$ids = 4625,4624
try {{
  Get-WinEvent -FilterHashtable @{{LogName='Security'; Id=$ids; StartTime=$since}} -ErrorAction Stop |
  ForEach-Object {{
    $x=[xml]$_.ToXml()
    $d=@{{}}
    foreach($n in $x.Event.EventData.Data){{ $d[$n.Name]=$n.'#text' }}
    [pscustomobject]@{{
      Id=$_.Id; Time=$_.TimeCreated.ToString('o');
      User=$d['TargetUserName']; Ip=$d['IpAddress']; Type=$d['LogonType']
    }}
  }} | ConvertTo-Json -Compress
}} catch {{ '' }}
"""


def run_windows(corr, once, window, interval=10):
    emit("-", "info", "Monitoring Windows Security log (4625/4624)")
    lookback = window if once else interval + 2
    seen = set()
    while True:
        ps = PS_QUERY.format(lookback=lookback)
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                capture_output=True, text=True, timeout=60).stdout.strip()
        except Exception as e:  # noqa
            emit("-", "error", f"PowerShell query failed: {e}")
            return
        if out:
            try:
                data = json.loads(out)
                if isinstance(data, dict):
                    data = [data]
            except json.JSONDecodeError:
                data = []
            for ev in data:
                key = (ev.get("Time"), ev.get("Id"), ev.get("User"), ev.get("Ip"))
                if key in seen:
                    continue
                seen.add(key)
                ip = ev.get("Ip") or "local"
                user = ev.get("User")
                if str(ev.get("Id")) == "4625":
                    corr.record_fail(ip, user)
                elif str(ev.get("Id")) == "4624":
                    corr.record_success(ip, user)
        if once:
            return
        if len(seen) > 20000:
            seen = set(list(seen)[-10000:])
        time.sleep(interval)


def main():
    ap = argparse.ArgumentParser(description="Brute-force / failed-logon monitor")
    ap.add_argument("--threshold", type=int, default=5)
    ap.add_argument("--window", type=int, default=60)
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()

    corr = Correlator(args.threshold, args.window)
    emit("-", "info",
         f"Brute-force monitor start (threshold={args.threshold}, "
         f"window={args.window}s)")
    try:
        if platform.system() == "Windows":
            run_windows(corr, args.once, args.window)
        else:
            run_linux(corr, args.once, args.window)
    except KeyboardInterrupt:
        emit("-", "info", "Stopped by operator")


if __name__ == "__main__":
    main()
