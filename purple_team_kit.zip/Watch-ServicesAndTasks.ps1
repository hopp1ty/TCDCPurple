<#
.SYNOPSIS
    Watch-ServicesAndTasks.ps1 — flag new/changed services & scheduled tasks.

.DESCRIPTION
    Blue-team detection. Baselines the host's Windows services and scheduled
    tasks, then polls on an interval and flags anything NEW or CHANGED:
      - new service install / changed binary path / start-type change  (T1543.003)
      - new scheduled task / changed action                            (T1053.005)
    These are two of the most common persistence + privesc footholds, so this
    pairs directly with the privesc monitor.

    Flags (does not remove) findings. Safe to run read-only as Administrator.

.EXAMPLE
    .\Watch-ServicesAndTasks.ps1                  # baseline + poll every 15s
    .\Watch-ServicesAndTasks.ps1 -IntervalSeconds 30
    .\Watch-ServicesAndTasks.ps1 -Once            # one snapshot vs saved baseline
#>

[CmdletBinding()]
param(
    [int]$IntervalSeconds = 15,
    [switch]$Once,
    [string]$AlertLog  = ".\service_task_alerts.log",
    [string]$StateFile = ".\service_task_baseline.json"
)

function Emit-Alert {
    param([string]$Technique,[string]$Severity,[string]$Message,[hashtable]$Evidence=@{})
    $a=[ordered]@{
        time=(Get-Date).ToUniversalTime().ToString("o")
        detector="service_task"; attack_technique=$Technique
        severity=$Severity; message=$Message; evidence=$Evidence; host=$env:COMPUTERNAME
    }
    $j=$a|ConvertTo-Json -Compress -Depth 6
    Write-Output $j
    Add-Content -Path $AlertLog -Value $j -ErrorAction SilentlyContinue
}

function Get-ServiceSnapshot {
    $m=@{}
    Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | ForEach-Object {
        $m[$_.Name]=@{ path=$_.PathName; start=$_.StartMode; account=$_.StartName; state=$_.State }
    }
    return $m
}

function Get-TaskSnapshot {
    $m=@{}
    Get-ScheduledTask -ErrorAction SilentlyContinue | ForEach-Object {
        $actions = ($_.Actions | ForEach-Object {
            ($_.Execute, $_.Arguments) -join ' '
        }) -join ' ; '
        $key = "$($_.TaskPath)$($_.TaskName)"
        $m[$key]=@{ action=$actions; author=$_.Author; state=$_.State.ToString() }
    }
    return $m
}

function Snapshot {
    return @{ services=(Get-ServiceSnapshot); tasks=(Get-TaskSnapshot) }
}

function Load-Baseline {
    if (Test-Path $StateFile) {
        try { return Get-Content $StateFile -Raw | ConvertFrom-Json } catch {}
    }
    return $null
}

function Save-Baseline {
    param($snap)
    $snap | ConvertTo-Json -Depth 8 | Set-Content $StateFile
}

# Convert PSCustomObject (from JSON) or hashtable into a plain hashtable.
function AsMap($obj) {
    $h=@{}
    if ($null -eq $obj) { return $h }
    if ($obj -is [hashtable]) { return $obj }
    foreach ($p in $obj.PSObject.Properties) { $h[$p.Name]=$p.Value }
    return $h
}

function Compare-Snapshots {
    param($old,$new)

    $oldSvc = AsMap $old.services ; $newSvc = AsMap $new.services
    $oldTsk = AsMap $old.tasks    ; $newTsk = AsMap $new.tasks

    # --- services ---
    foreach ($name in $newSvc.Keys) {
        $n = AsMap $newSvc[$name]
        if (-not $oldSvc.ContainsKey($name)) {
            Emit-Alert "T1543.003" "high" "New service installed: $name" `
                @{ service=$name; path=$n.path; start=$n.start; account=$n.account }
            continue
        }
        $o = AsMap $oldSvc[$name]
        if ($o.path -ne $n.path) {
            Emit-Alert "T1543.003" "high" "Service binary path changed: $name" `
                @{ service=$name; old=$o.path; new=$n.path }
        }
        if ($o.start -ne $n.start) {
            Emit-Alert "T1543.003" "medium" "Service start-type changed: $name" `
                @{ service=$name; old=$o.start; new=$n.start }
        }
        if ($o.account -ne $n.account) {
            Emit-Alert "T1543.003" "medium" "Service run-as account changed: $name" `
                @{ service=$name; old=$o.account; new=$n.account }
        }
    }

    # --- scheduled tasks ---
    foreach ($key in $newTsk.Keys) {
        $n = AsMap $newTsk[$key]
        if (-not $oldTsk.ContainsKey($key)) {
            Emit-Alert "T1053.005" "high" "New scheduled task: $key" `
                @{ task=$key; action=$n.action; author=$n.author }
            continue
        }
        $o = AsMap $oldTsk[$key]
        if ($o.action -ne $n.action) {
            Emit-Alert "T1053.005" "high" "Scheduled task action changed: $key" `
                @{ task=$key; old=$o.action; new=$n.action }
        }
    }
}

# ---- main ----
Emit-Alert "-" "info" "Service/Task watcher starting on $env:COMPUTERNAME"
$baseline = Load-Baseline
$current  = Snapshot

if ($null -eq $baseline) {
    Save-Baseline $current
    $svcCount = (AsMap $current.services).Count
    $tskCount = (AsMap $current.tasks).Count
    Emit-Alert "-" "info" "Baseline captured: $svcCount services, $tskCount tasks"
    $baseline = $current
} else {
    Compare-Snapshots $baseline $current
    $baseline = $current
}

if ($Once) { Emit-Alert "-" "info" "One-shot comparison complete"; return }

try {
    while ($true) {
        Start-Sleep -Seconds $IntervalSeconds
        $new = Snapshot
        Compare-Snapshots $baseline $new
        $baseline = $new
        Save-Baseline $new
    }
} finally {
    Emit-Alert "-" "info" "Watcher stopped by operator"
}
