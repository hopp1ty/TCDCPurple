CUSTOM DETECTION SCRIPTS — README
=================================

Five standalone attack-detection monitors for a purple-team exercise. Each is
its own file so you can run them in separate terminals, on the host or data
source that fits. All of them FLAG activity only — nothing offensive, nothing
destructive. Every alert is JSON-lines to stdout and to a per-script .log file,
tagged with an ATT&CK technique id so you can line red actions up to detections.

----------------------------------------------------------------------
TERMINAL 1 — brute_force_monitor.py        (ATT&CK T1110)
----------------------------------------------------------------------
Correlates failed logons per source IP in a sliding window; escalates when a
failure burst is followed by a success (possible crack).
  Linux :  sudo python3 brute_force_monitor.py
  Windows: python3 brute_force_monitor.py        (reads Security 4625/4624)
  Options: --threshold 5 --window 60 --once
  Alerts : bruteforce_alerts.log

----------------------------------------------------------------------
TERMINAL 2 — Watch-ServicesAndTasks.ps1    (T1543.003, T1053.005)
----------------------------------------------------------------------
Windows. Baselines services + scheduled tasks, polls, flags new/changed ones.
  Run    : .\Watch-ServicesAndTasks.ps1            (elevated)
  Options: -IntervalSeconds 30 -Once
  State  : service_task_baseline.json  (delete to re-baseline)
  Alerts : service_task_alerts.log

----------------------------------------------------------------------
TERMINAL 3 — dns_exfil_monitor.py          (T1048.003 / T1071.004)
----------------------------------------------------------------------
Flags DNS tunneling/exfil via label entropy, query length, volume, and unique-
subdomain count per parent domain.
  Zeek   : python3 dns_exfil_monitor.py --zeek /opt/zeek/logs/current/dns.log
  Live   : sudo python3 dns_exfil_monitor.py --live eth0    (needs scapy)
  Options: --entropy 3.5 --minlen 50 --window 60 --vol 80 --uniq 40
  Alerts : dns_exfil_alerts.log

----------------------------------------------------------------------
TERMINAL 4 — beacon_detector.py            (T1071 / T1571)
----------------------------------------------------------------------
Finds regular-cadence C2 beacons in a Zeek conn.log via interval coefficient
of variation + jitter ratio. Batch; re-run on a rolling window.
  Run    : python3 beacon_detector.py --zeek /opt/zeek/logs/current/conn.log
  Loop   : python3 beacon_detector.py --zeek conn.log --watch 300
  Options: --min-conns 8 --cv 0.15 --min-span 600
  Alerts : beacon_alerts.log

----------------------------------------------------------------------
TERMINAL 5 — impossible_travel.py          (T1078)
----------------------------------------------------------------------
Flags logons implying faster-than-possible travel, new-country logons, and
multi-IP bursts per user.
  With geo: python3 impossible_travel.py --geodb GeoLite2-City.mmdb --log /var/log/auth.log
  JSON in : python3 impossible_travel.py --json logons.jsonl --once
  Degraded: runs without a geo DB (multi-IP burst flag only)
  Alerts  : impossible_travel_alerts.log

DEPENDENCIES
------------
- Python 3.8+ for the .py scripts. Standard library only, except:
    dns_exfil_monitor.py --live   needs:  pip install scapy
    impossible_travel.py --geodb  needs:  pip install geoip2  + GeoLite2-City.mmdb
- PowerShell 5+ (elevated) for the .ps1 scripts.
- Zeek-based scripts expect standard Zeek dns.log / conn.log (Security Onion
  produces these out of the box).

FEEDING FROM A SIEM INSTEAD
---------------------------
These parse logs directly so they work on a bare host. In a full environment,
point them at the live Zeek logs, or tail the per-script *_alerts.log into
Elastic/Wazuh and correlate alongside Sigma rules.

RUNNING AS AN EXERCISE
----------------------
1. Start the relevant monitors (plus the privesc monitors + hardening audit).
2. Red runs one atomic for a mapped technique (T1110, T1543.003, T1048.003,
   T1071, T1078).
3. Confirm the matching alert appears; log the timestamp.
4. Any technique that fires on red but produces NO alert = a detection gap to
   build. That list is the real deliverable of the day.
