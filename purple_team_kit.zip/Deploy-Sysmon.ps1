<#
.SYNOPSIS
    Deploy-Sysmon.ps1 — install/update Sysmon with a tuned config.

.DESCRIPTION
    Blue-team visibility. Installs (or updates the config of) Microsoft Sysmon
    using a community config (Olaf Hartong's sysmon-modular or SwiftOnSecurity).
    Sysmon is the single biggest host-telemetry upgrade for a purple event:
    process creation w/ command line + hashes, network connections, image
    loads, driver loads, named pipes, WMI events, registry changes.

    Idempotent:
      - If Sysmon isn't installed, installs it with the chosen config.
      - If it is, updates to the chosen config (-c).
      - -Audit just reports current install/config status and exits.

    You must supply Sysmon.exe and a config, OR allow download from the
    official sources. This script does NOT bundle binaries.

.PARAMETER SysmonPath
    Path to Sysmon64.exe. If omitted and -Download is set, fetched from
    Microsoft Sysinternals.

.PARAMETER ConfigPath
    Path to a sysmonconfig.xml. If omitted and -Download is set, fetches
    Olaf Hartong's sysmon-modular default (or SwiftOnSecurity with -Config swift).

.EXAMPLE
    .\Deploy-Sysmon.ps1 -Audit
    .\Deploy-Sysmon.ps1 -SysmonPath .\Sysmon64.exe -ConfigPath .\sysmonconfig.xml
    .\Deploy-Sysmon.ps1 -Download                      # fetch both, install
    .\Deploy-Sysmon.ps1 -Download -Config swift        # use SwiftOnSecurity cfg

.NOTES
    Run elevated. Downloads require outbound HTTPS to microsoft.com / github.com.
    Review the config before enforcing in production.
#>

[CmdletBinding()]
param(
    [switch]$Audit,
    [switch]$Download,
    [ValidateSet('modular','swift')][string]$Config = 'modular',
    [string]$SysmonPath,
    [string]$ConfigPath,
    [string]$WorkDir = ".\sysmon_deploy",
    [string]$AlertLog = ".\sysmon_deploy.log"
)

if (-not ([Security.Principal.WindowsPrincipal] `
          [Security.Principal.WindowsIdentity]::GetCurrent()
         ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Run this from an elevated (Administrator) PowerShell prompt."
    exit 1
}

function Log { param([string]$t)
    $l="{0}  {1}" -f (Get-Date).ToString("s"),$t
    Write-Host $l; Add-Content -Path $AlertLog -Value $l -ErrorAction SilentlyContinue
}

$SYSINTERNALS_URL = "https://download.sysinternals.com/files/Sysmon.zip"
$CFG_MODULAR = "https://raw.githubusercontent.com/olafhartong/sysmon-modular/master/sysmonconfig.xml"
$CFG_SWIFT   = "https://raw.githubusercontent.com/SwiftOnSecurity/sysmon-config/master/sysmonconfig-export.xml"

function Get-InstalledSysmon {
    foreach ($n in 'Sysmon64','Sysmon') {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc) { return $svc }
    }
    return $null
}

function Audit-Status {
    $svc = Get-InstalledSysmon
    if ($svc) {
        Log "Sysmon INSTALLED: service '$($svc.Name)' status=$($svc.Status)"
        $drv = Get-CimInstance Win32_SystemDriver -Filter "Name='SysmonDrv'" -ErrorAction SilentlyContinue
        if ($drv) { Log "SysmonDrv driver state=$($drv.State)" }
        try {
            $log = Get-WinEvent -ListLog "Microsoft-Windows-Sysmon/Operational" -ErrorAction Stop
            Log "Operational log present: $($log.RecordCount) records, max size $($log.MaximumSizeInBytes) bytes"
        } catch { Log "Sysmon operational log not found." }
    } else {
        Log "Sysmon NOT installed."
    }
}

if ($Audit) { Audit-Status; return }

New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null

# Resolve Sysmon binary
if (-not $SysmonPath) {
    if ($Download) {
        $zip = Join-Path $WorkDir "Sysmon.zip"
        Log "Downloading Sysmon from Sysinternals..."
        try {
            Invoke-WebRequest -Uri $SYSINTERNALS_URL -OutFile $zip -UseBasicParsing -ErrorAction Stop
            Expand-Archive -Path $zip -DestinationPath $WorkDir -Force
            $SysmonPath = Join-Path $WorkDir "Sysmon64.exe"
        } catch { Log "ERROR downloading Sysmon: $($_.Exception.Message)"; return }
    } else {
        Log "No -SysmonPath and no -Download. Provide Sysmon64.exe or pass -Download."; return
    }
}
if (-not (Test-Path $SysmonPath)) { Log "Sysmon binary not found at $SysmonPath"; return }

# Resolve config
if (-not $ConfigPath) {
    if ($Download) {
        $url = if ($Config -eq 'swift') { $CFG_SWIFT } else { $CFG_MODULAR }
        $ConfigPath = Join-Path $WorkDir "sysmonconfig.xml"
        Log "Downloading '$Config' config..."
        try {
            Invoke-WebRequest -Uri $url -OutFile $ConfigPath -UseBasicParsing -ErrorAction Stop
        } catch { Log "ERROR downloading config: $($_.Exception.Message)"; return }
    } else {
        Log "No -ConfigPath and no -Download. Provide sysmonconfig.xml or pass -Download."; return
    }
}
if (-not (Test-Path $ConfigPath)) { Log "Config not found at $ConfigPath"; return }

# Accept EULA automatically is implied by -accepteula; it's Microsoft's tool.
$existing = Get-InstalledSysmon
try {
    if ($existing) {
        Log "Sysmon already installed; updating configuration..."
        & $SysmonPath -c $ConfigPath 2>&1 | ForEach-Object { Log $_ }
    } else {
        Log "Installing Sysmon with config $ConfigPath ..."
        & $SysmonPath -accepteula -i $ConfigPath 2>&1 | ForEach-Object { Log $_ }
    }
} catch { Log "ERROR running Sysmon: $($_.Exception.Message)"; return }

# Bump the operational log size so it doesn't roll during the exercise.
try {
    wevtutil sl "Microsoft-Windows-Sysmon/Operational" /ms:1073741824 | Out-Null
    Log "Set Sysmon operational log max size to 1 GB."
} catch { Log "Could not resize Sysmon log: $($_.Exception.Message)" }

Audit-Status
Log "Done. Your detection scripts (e.g. Invoke-PrivescMonitor.ps1) will now see Sysmon events."
