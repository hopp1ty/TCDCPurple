<#
.SYNOPSIS
    Watch-CanaryAccounts.ps1 — honey-account / honey-SPN tripwire monitor.

.DESCRIPTION
    Blue-team deception detector. You designate one or more "canary" accounts
    (and optionally SPNs) that NO legitimate process should ever use. This
    script watches authentication events for ANY reference to them and alerts
    immediately — these are near-zero-false-positive signals of an intruder
    enumerating or using planted credentials.

    Watches (local Security log, and DC logs if run on a domain controller):
      4624 / 4625  logon success / failure for a canary user     (T1078)
      4768         Kerberos TGT requested for a canary            (T1558)
      4769         Kerberos service ticket requested for canary SPN
                   (Kerberoasting bait)                           (T1558.003)
      4662 / 5136  directory object read/modify referencing canary (recon)

    This does NOT create accounts. It tells you exactly how to plant good bait
    (see -ShowSetup) and then monitors for touches.

.PARAMETER Users
    One or more canary account sAMAccountNames to watch (e.g. svc_backup_adm).

.PARAMETER Spns
    Optional canary SPNs to watch in 4769 events (Kerberoast bait).

.EXAMPLE
    .\Watch-CanaryAccounts.ps1 -Users svc_sql_admin,helpdesk_da
    .\Watch-CanaryAccounts.ps1 -Users decoy_admin -Spns MSSQLSvc/decoy.corp.local:1433
    .\Watch-CanaryAccounts.ps1 -ShowSetup        # print bait-planting guidance

.NOTES
    Run elevated. On a DC, point it there to catch Kerberos (4768/4769) and
    directory recon (4662). Requires the relevant audit subcategories ON —
    Invoke-WindowsHardening.ps1 -Apply enables them.
#>

[CmdletBinding()]
param(
    [string[]]$Users,
    [string[]]$Spns,
    [switch]$ShowSetup,
    [switch]$Once,
    [int]$IntervalSeconds = 10,
    [int]$LookbackMinutes = 5,
    [string]$AlertLog = ".\canary_alerts.log"
)

function Emit-Alert {
    param([string]$Technique,[string]$Severity,[string]$Message,[hashtable]$Evidence=@{})
    $a=[ordered]@{
        time=(Get-Date).ToUniversalTime().ToString("o")
        detector="canary_account"; attack_technique=$Technique
        severity=$Severity; message=$Message; evidence=$Evidence; host=$env:COMPUTERNAME
    }
    $j=$a|ConvertTo-Json -Compress -Depth 6
    Write-Output $j
    Add-Content -Path $AlertLog -Value $j -ErrorAction SilentlyContinue
}

if ($ShowSetup) {
@"
CANARY / HONEY-ACCOUNT SETUP (plant the bait, then run this to watch)
--------------------------------------------------------------------
Make the account IRRESISTIBLE but USELESS, and never log in with it:

 1. Create a domain account with a tempting name:
      New-ADUser -Name 'svc_sql_admin' -SamAccountName 'svc_sql_admin' ``
        -Enabled `$true -AccountPassword (Read-Host -AsSecureString) ``
        -Description 'SQL service admin'
 2. Make it LOOK privileged (bait for BloodHound/enumeration) WITHOUT real
    power — e.g. add to a decoy group, or set adminCount=1 cosmetically, but
    do NOT grant it rights you care about. A well-tuned decoy looks like a
    Domain Admin service account and leads nowhere.
 3. Kerberoast bait: give it a fake SPN so it shows up in Kerberoast scans:
      setspn -s MSSQLSvc/decoy.corp.local:1433 svc_sql_admin
    Any 4769 for that SPN = someone is Kerberoasting.
 4. Credential bait: drop the 'password' in a honey file (e.g. a fake
    passwords.xlsx on a share, or a Canarytoken) — any logon attempt = intruder.
 5. NEVER authenticate with it yourself. Then:
      .\Watch-CanaryAccounts.ps1 -Users svc_sql_admin -Spns MSSQLSvc/decoy.corp.local:1433

Because nothing legitimate touches these, a single hit is high-confidence.
"@ | Write-Host
    return
}

if (-not $Users -and -not $Spns) {
    Write-Error "Provide -Users <canary accounts> and/or -Spns, or run -ShowSetup."
    exit 1
}

$UserSet = @{}; foreach ($u in $Users) { $UserSet[$u.ToLower()] = $true }
$SpnSet  = @{}; foreach ($s in $Spns)  { $SpnSet[$s.ToLower()]  = $true }

function Scan {
    param([datetime]$Since)
    $ids = 4624,4625,4768,4769,4662,5136
    try {
        $events = Get-WinEvent -FilterHashtable @{
            LogName='Security'; Id=$ids; StartTime=$Since
        } -ErrorAction Stop
    } catch { return }

    foreach ($e in $events) {
        $x = [xml]$e.ToXml()
        $d = @{}
        foreach ($n in $x.Event.EventData.Data) { $d[$n.Name] = $n.'#text' }

        $target = ($d['TargetUserName']) 
        $svc    = ($d['ServiceName'])
        $ip     = $d['IpAddress']
        $srcUser= $d['SubjectUserName']
        $tl     = if ($target) { $target.ToLower() } else { "" }

        $hitUser = $tl -and $UserSet.ContainsKey($tl)
        $hitSpn  = $svc -and $SpnSet.ContainsKey($svc.ToLower())

        if (-not ($hitUser -or $hitSpn)) { continue }

        switch ([int]$e.Id) {
            4624 { Emit-Alert "T1078" "critical" "Canary account LOGON SUCCESS: $target" `
                     @{ event=4624; user=$target; src_ip=$ip; logon_type=$d['LogonType'] } }
            4625 { Emit-Alert "T1078" "high" "Canary account logon FAILURE (someone tried it): $target" `
                     @{ event=4625; user=$target; src_ip=$ip; status=$d['Status'] } }
            4768 { Emit-Alert "T1558" "high" "Kerberos TGT requested for canary: $target" `
                     @{ event=4768; user=$target; src_ip=$ip } }
            4769 { Emit-Alert "T1558.003" "high" "Service ticket requested for canary SPN (Kerberoast bait): $svc" `
                     @{ event=4769; spn=$svc; user=$target; src_ip=$ip; enc=$d['TicketEncryptionType'] } }
            4662 { Emit-Alert "T1087" "medium" "Directory object access referencing canary: $target" `
                     @{ event=4662; user=$target; by=$srcUser } }
            5136 { Emit-Alert "T1098" "high" "Directory object MODIFIED referencing canary: $target" `
                     @{ event=5136; user=$target; by=$srcUser } }
        }
    }
}

Emit-Alert "-" "info" "Canary watcher starting. Users=$($Users -join ',') Spns=$($Spns -join ',')"
$last = (Get-Date).AddMinutes(-$LookbackMinutes)
Scan -Since $last
if ($Once) { Emit-Alert "-" "info" "One-shot scan complete"; return }

try {
    while ($true) {
        $cursor = Get-Date
        Start-Sleep -Seconds $IntervalSeconds
        Scan -Since $last
        $last = $cursor
    }
} finally {
    Emit-Alert "-" "info" "Canary watcher stopped by operator"
}
