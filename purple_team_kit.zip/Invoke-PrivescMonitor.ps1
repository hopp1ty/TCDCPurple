<#
.SYNOPSIS
    Invoke-PrivescMonitor.ps1  —  Windows privilege-escalation detection monitor

.DESCRIPTION
    Blue-team detection script for a purple-team exercise. It does NOT perform
    privilege escalation. It reads Windows telemetry (Security log, Sysmon
    operational log, and live system state) and raises flagged alerts when
    behavior consistent with common privesc techniques appears, so the blue
    team can confirm detections fire when the red team runs the matching atomic.

    Each alert carries an ATT&CK technique id for the run sheet.

.NOTES
    Run from an elevated PowerShell prompt for full event-log access.
    Sysmon coverage assumes a config such as SwiftOnSecurity or sysmon-modular.

.EXAMPLE
    # Continuous monitor, polling every 15s
    .\Invoke-PrivescMonitor.ps1 -Follow

    # One-shot scan of recent events + current state
    .\Invoke-PrivescMonitor.ps1 -Once
#>

[CmdletBinding()]
param(
    [switch]$Follow,
    [switch]$Once,
    [int]$IntervalSeconds = 15,
    [int]$LookbackMinutes = 10,
    [string]$AlertLog = ".\privesc_alerts.log"
)

function Emit-Alert {
    param(
        [string]$Technique,
        [string]$Severity,
        [string]$Message,
        [hashtable]$Evidence = @{}
    )
    $alert = [ordered]@{
        time             = (Get-Date).ToUniversalTime().ToString("o")
        attack_technique = $Technique
        severity         = $Severity
        message          = $Message
        evidence         = $Evidence
        host             = $env:COMPUTERNAME
    }
    $json = $alert | ConvertTo-Json -Compress -Depth 6
    Write-Output $json
    Add-Content -Path $AlertLog -Value $json -ErrorAction SilentlyContinue
}

# ---- Security log event-ID based detections -------------------------------
# Maps Windows Security event IDs to ATT&CK techniques relevant to privesc.
$SecurityEventMap = @{
    4672 = @{ t = "T1078";     sev = "medium"; m = "Special privileges assigned to new logon (admin-equiv token)" }
    4673 = @{ t = "T1134";     sev = "medium"; m = "Sensitive privilege use" }
    4674 = @{ t = "T1134";     sev = "low";    m = "Operation attempted on privileged object" }
    4728 = @{ t = "T1098";     sev = "high";   m = "Member added to a security-enabled global group" }
    4732 = @{ t = "T1098";     sev = "high";   m = "Member added to a security-enabled local group (e.g. Administrators)" }
    4756 = @{ t = "T1098";     sev = "high";   m = "Member added to a security-enabled universal group" }
    4720 = @{ t = "T1136.001"; sev = "medium"; m = "User account created" }
    4697 = @{ t = "T1543.003"; sev = "high";   m = "Service installed (possible privesc persistence)" }
    4698 = @{ t = "T1053.005"; sev = "medium"; m = "Scheduled task created" }
    4648 = @{ t = "T1134.002"; sev = "low";    m = "Logon with explicit credentials (runas / token use)" }
}

# ---- Sysmon operational-log detections ------------------------------------
# Event ID 1 = process create; 13 = registry value set; 11 = file create.
$SysmonLog = "Microsoft-Windows-Sysmon/Operational"

# Known UAC-bypass / privesc registry & process indicators.
$UacBypassHints = @(
    "fodhelper.exe", "computerdefaults.exe", "eventvwr.exe",
    "sdclt.exe", "slui.exe", "cmstp.exe", "wsreset.exe"
)
$CredDumpHints = @(
    "mimikatz", "sekurlsa", "lsadump", "procdump.*lsass",
    "comsvcs.*MiniDump", "rubeus", "secretsdump"
)

function Scan-SecurityLog {
    param([datetime]$Since)
    $ids = $SecurityEventMap.Keys
    try {
        $events = Get-WinEvent -FilterHashtable @{
            LogName   = 'Security'
            Id        = $ids
            StartTime = $Since
        } -ErrorAction Stop
    } catch {
        return
    }
    foreach ($e in $events) {
        $info = $SecurityEventMap[[int]$e.Id]
        if ($null -eq $info) { continue }
        $msg = ($e.Message -split "`n" | Select-Object -First 1).Trim()
        Emit-Alert -Technique $info.t -Severity $info.sev -Message $info.m -Evidence @{
            event_id = $e.Id
            record   = $e.RecordId
            detail   = $msg.Substring(0, [Math]::Min(300, $msg.Length))
        }
    }
}

function Scan-SysmonLog {
    param([datetime]$Since)
    try {
        $events = Get-WinEvent -FilterHashtable @{
            LogName   = $SysmonLog
            Id        = @(1, 11, 13)
            StartTime = $Since
        } -ErrorAction Stop
    } catch {
        return
    }
    foreach ($e in $events) {
        $text = $e.Message
        if ([string]::IsNullOrEmpty($text)) { continue }

        # UAC bypass auto-elevate binaries spawning children
        foreach ($h in $UacBypassHints) {
            if ($text -match [regex]::Escape($h)) {
                Emit-Alert -Technique "T1548.002" -Severity "high" `
                    -Message "Possible UAC bypass via auto-elevate binary: $h" `
                    -Evidence @{ event_id = $e.Id; detail = ($text -split "`n" | Select-Object -First 4) -join " | " }
                break
            }
        }

        # Credential-dumping tradecraft (often paired with privesc)
        foreach ($h in $CredDumpHints) {
            if ($text -match $h) {
                Emit-Alert -Technique "T1003" -Severity "high" `
                    -Message "Possible credential-access tooling: $h" `
                    -Evidence @{ event_id = $e.Id; detail = ($text -split "`n" | Select-Object -First 4) -join " | " }
                break
            }
        }

        # Named-pipe / token impersonation hints (common in local privesc)
        if ($text -match "\\\\.\\pipe\\.*(sys|svc|mojo).*" -and $e.Id -eq 1) {
            Emit-Alert -Technique "T1134.001" -Severity "medium" `
                -Message "Process referencing suspicious named pipe (token/impersonation)" `
                -Evidence @{ event_id = $e.Id; detail = ($text -split "`n" | Select-Object -First 3) -join " | " }
        }
    }
}

function Scan-LiveState {
    # Snapshot checks that don't depend on event logs.

    # 1. Unquoted service paths with spaces (classic privesc vector)
    try {
        Get-CimInstance Win32_Service -ErrorAction Stop | ForEach-Object {
            $p = $_.PathName
            if ($p -and $p -notmatch '^\s*"' -and $p -match '\s' -and $p -notmatch '^\s*[A-Za-z]:\\Windows\\') {
                Emit-Alert -Technique "T1574.009" -Severity "medium" `
                    -Message "Unquoted service path (privesc vector): $($_.Name)" `
                    -Evidence @{ service = $_.Name; path = $p; start = $_.StartMode }
            }
        }
    } catch {}

    # 2. Members of local Administrators (for drift comparison by blue team)
    try {
        $admins = Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop |
            Select-Object -ExpandProperty Name
        Emit-Alert -Technique "T1098" -Severity "info" `
            -Message "Current local Administrators membership snapshot" `
            -Evidence @{ members = $admins }
    } catch {}

    # 3. AlwaysInstallElevated policy (lets MSI run as SYSTEM)
    foreach ($hive in @("HKLM", "HKCU")) {
        $key = "$hive`:\SOFTWARE\Policies\Microsoft\Windows\Installer"
        try {
            $v = (Get-ItemProperty -Path $key -Name AlwaysInstallElevated -ErrorAction Stop).AlwaysInstallElevated
            if ($v -eq 1) {
                Emit-Alert -Technique "T1548.002" -Severity "high" `
                    -Message "AlwaysInstallElevated enabled ($hive) — SYSTEM-level MSI privesc" `
                    -Evidence @{ hive = $hive }
            }
        } catch {}
    }
}

function Invoke-Scan {
    param([datetime]$Since)
    Scan-SecurityLog -Since $Since
    Scan-SysmonLog   -Since $Since
    Scan-LiveState
}

# ---- main -----------------------------------------------------------------
Emit-Alert -Technique "-" -Severity "info" -Message "Starting Windows privesc monitor"

if ($Once -or (-not $Follow)) {
    Invoke-Scan -Since (Get-Date).AddMinutes(-$LookbackMinutes)
    Emit-Alert -Technique "-" -Severity "info" -Message "One-shot scan complete"
    return
}

$last = (Get-Date).AddMinutes(-$LookbackMinutes)
try {
    while ($true) {
        $cursor = Get-Date
        Invoke-Scan -Since $last
        $last = $cursor
        Start-Sleep -Seconds $IntervalSeconds
    }
} finally {
    Emit-Alert -Technique "-" -Severity "info" -Message "Monitor stopped by operator"
}
